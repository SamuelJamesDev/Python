# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 09:50:35 2022

@author: SamuelJames
"""

import xml.etree.ElementTree as ET
for event, elem in ET.iterparse("users.xml"):
  if elem.tag == 'Name':
    print(ET.tostring(elem, 'UTF-8', 'xml'))
    elem.clear()