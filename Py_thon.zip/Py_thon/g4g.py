# -*- coding: utf-8 -*-
"""
Created on Mon Mar 28 08:13:25 2022

@author: SamuelJames

Scrape Geeks 4 Geeks python page
"""

import requests
import urllib3
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import pyfiglet
from bs4 import BeautifulSoup

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def scrape():
    try:
        r = requests.get("https://www.geeksforgeeks.org/python-programming-language/", verify=False)
        #data = json.loads(r.text)

        soup = BeautifulSoup(r.content, 'html.parser')
        s = soup.find('div', class_='Basics')
        s2 = soup.find('div', class_='io')
        s3 = soup.find('div', class_='Data Types')
        s4 = soup.find('div', class_='Machine Learning with Python')
        
        lines = (s.findAll('a', href=True))
        lines2 = (s2.findAll('a'))
        lines3 = (s3.findAll('a'))
        lines4 = (s4.findAll('a'))
        
        for line in lines:
            print(line.text)
        for line in lines2:
            print(line.text)
        for line in lines3:
            print(line.text)
        for line in lines4:
            print(line.text)
    
    except KeyboardInterrupt:
        print(pyfiglet.figlet_format("\nSEE YOU SPACE COWBOY..."))

scrape()