import time
import os
from colorama import init
from termcolor import colored
import random 
import sys
# use Colorama to make Termcolor work on Windows too
init()


x0 = ' 0 '
x1 = ' 0 '
x2 = ' 0 '
x3 = ' 0 '
x4 = ' 0 '
x5 = ' 0 '
x6 = ' 0 '
x7 = ' 0 '
x8 = ' 0 '
x9 = ' 0 '

cn = ' 1 '

t1 = '___________________________________\n'
t2 = '\n|_________________________________|'
l = [' 0 ', ' 0 ', ' 0 ', ' 0 ', ' 0 ']
l2 = [' 0 ', ' 0 ', ' 0 ', ' 0 ', ' 0 ']
l3 = [' 0 ', ' 0 ', ' 0 ', ' 0 ', ' 0 ']


def classicLoad():
    ding = 'loading'
    x = '.'
    for i in range(10):
        sys.stdout.write('Loading' + x*i)
        sys.stdout.write('\r')
        sys.stdout.flush()
        time.sleep(1)
        

def prettyLoad():
    animation = [
        "[        ]",
        "[=       ]",
        "[===     ]",
        "[====    ]",
        "[=====   ]",
        "[======  ]",
        "[======= ]",
        "[========]",
        "[ =======]",
        "[  ======]",
        "[   =====]",
        "[    ====]",
        "[     ===]",
        "[      ==]",
        "[       =]",
        "[        ]",
        "[        ]"
        ]

    notcomplete = True
    
    i = 0

    while notcomplete:
        print(animation[i % len(animation)], end='\r')
        time.sleep(.1)
        i += 1

def otherLoad():
    bar = [
        " [=       ]",
        " [ =      ]",
        " [  =     ]",
        " [   =    ]",
        " [    =   ]",
        " [     =  ]",
        " [      = ]",
        " [       =]",
        " [      = ]",
        " [     =  ]",
        " [    =   ]",
        " [   =    ]",
        " [  =     ]",
        " [ =      ]",
    ]
    i = 0

    while True:
        print(bar[i % len(bar)], end="\r")
        time.sleep(.2)
        i += 1

def makeBox():
    box = t1 + str(l) + '\n' + str(l2) + '\n' + str(l3) + t2
    return box

def cycle(l):
    run = makeBox()
    
    print(colored(run, 'green', 'on_grey'), end='\r')
    
    time.sleep(.5)
    os.system('cls')
    x = random.randint(0, 4)
    l[x] = ' 1 '   

def loadingBox():
    for i in range(10):
        cycle(l)
        cycle(l2)
        cycle(l3)
    
    print(colored("ENCRYPT & DECRYPT COMPLETE... ", 'green', 'on_grey'))
#_______________
#loadingBox()
#otherLoad()
prettyLoad()
#classicLoad()