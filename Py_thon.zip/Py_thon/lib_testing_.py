# -*- coding: utf-8 -*-
"""
Created on Tue May  3 07:53:25 2022

@author: SamuelJames
"""

import FWRQ

menu = '''
╔═════════════════╗
║ REQUEST CHOICES ║
╠═════════════════╣
║ 1 - Agents      ║
║ 2 - Tickets     ║
║ 3 - Requesters  ║
╚═════════════════╝
'''
    

def runChoice():
    print(menu)
    inp = str(input('Enter your choice:\n'))
    if inp == 'exit':
        exit()
    if inp != '1' and inp != '2' and inp != '3':
        print('Invalid Choice, try again...')
        runChoice()
    if inp == '1':
        print(FWRQ.agentPull())
        runChoice()
    elif inp == '2':
        print(FWRQ.ticketPull())
        runChoice()
    else:
        print(FWRQ.requesterPull())
        runChoice()
runChoice()
'''
ids, names = FWRQ.assetIds()

print(ids[1], names[1])

check = FWRQ.specifyAsset(ids[1])
print(check)
'''