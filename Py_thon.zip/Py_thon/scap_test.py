# -*- coding: utf-8 -*-
"""
Created on Wed Apr  6 11:04:28 2022

@author: SamuelJames
"""
import logging
import sys
logging.getLogger("scapy").setLevel(1)
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
#from scapy.all import *
import socket
import scapy.all as scapy
import tcpdump

'''
probe_list = []

ap_name= input("Enter the name of access point:\n")

def Probe_info(pkt) :
   if pkt.haslayer(Dot11ProbeReq) :
      client_name = pkt.info
      
      if client_name == ap_name :
         if pkt.addr2 not in Probe_info:
            Print("New Probe request--", client_name)
            Print("MAC is --", pkt.addr2)
            Probe_list.append(pkt.addr2)
            
sniff(iface = "mon0", prn = Probe_info)
'''

# Extracted Packet Format 
Pkt_Info = """
---------------[ Packet Captured ]-----------------------
 Subtype  : {}
 Address 1  : {}
 Address 2 : {} [BSSID]
 Address 3  : {}
 Address 4 : {}
 AP  : {} [SSID]

"""

# Founded Access Point List
ap_list = []

# For Extracting Available Access Points
def PacketHandler(pkt) :
    if pkt.haslayer(scapy.Dot11Elt) and pkt.type == 0 and pkt.subtype == 8 :
        if pkt.addr2 not in ap_list:
            ap_list.append(pkt.addr2)
    print(Pkt_Info.format(pkt.subtype,pkt.addr1, pkt.addr2, pkt.addr3, pkt.addr4, pkt.info)
 
scapy.sniff(iface = "mon0", prn = PacketHandler, count=1)