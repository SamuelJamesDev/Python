# -*- coding: utf-8 -*-
"""
Created on Fri Jan  7 09:09:23 2022

@author: SamuelJames
"""
import csv
from tqdm import tqdm
import time

def loadbar():
    for i in tqdm (range (100), 
               desc="Checking Assets For Missing Values...", 
               ascii=False, ncols=75):
        time.sleep(0.02)

def openPrgm():
    logo = '''
    M.A.T.T. V1.0.9 
    Missing Asset Tracking and Transitioning
      .-.
     (o.o)
      |=|
     __|__
   //.=|=.\\
  // .=|=. \\
  \\ .=|=. //
   \\(_=_)//
    (:| |:)
     || ||
     () ()
     || ||
     || ||
    ==' '==
    '''
    print(logo)
    inp = str(input("Enter [C] to Continue....\n"))
    if inp == 'C' or inp == 'c':
        return
    else:
        openPrgm()
    
def findUnused():
    count = 0
    un = []
    with open("INVENTORY.csv", "r") as f:
        csvreader = csv.reader(f, delimiter=",")
        for row in csvreader:
            if "None" in row:
                un.append(row)
                
        for i in range(len(un)):
            if un[i][0] != '':
                count += 1
                print('++++++++++++++++++++++++++++++++++++++++++++++++++++++')
                print('NAME: ',un[i][0], '\nASSET WITH NONE: ', un[i][1])
                print('++++++++++++++++++++++++++++++++++++++++++++++++++++++')
        print(count, 'ASSIGNED ASSETS ARE MISSING VALUES')
openPrgm()
loadbar()
findUnused()