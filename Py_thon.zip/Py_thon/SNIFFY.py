# -*- coding: utf-8 -*-
#! /usr/bin/env python
"""
Created on Wed Apr  6 11:04:28 2022

@author: SamuelJames
"""

from scapy.all import *
'''
def arp_monitor_callback(pkt):
    if ARP in pkt and pkt[ARP].op in (1,2): #who-has or is-at
        return pkt.sprintf("%ARP.hwsrc% %ARP.psrc%")

check = sniff(prn=arp_monitor_callback, filter="arp", store=0)
print(check)

from scapy.all import *
import socket
# importing the subprocess module
import subprocess

#winList = get_windows_if_list()
intfList = get_if_list()

# Extract the guids from the interface list
guidsFromIntfList = [(e.split("_"))[0] for e in intfList]

print(guidsFromIntfList)

# using the check_output() for having the network term retrieval
devices = subprocess.check_output(['netsh','wlan','show','network'])
  
# decode it to strings
devices = devices.decode('ascii')
devices= devices.replace("\r","")
  
# displaying the information
print(devices)
'''

probe_list = []

#ap_name= input("Enter the name of access point:\n")

def Probe_info(pkt) :
   if pkt.haslayer(Dot11ProbeReq) :
      client_name = pkt.info
      print('Client Name:\n', client_name)
      if client_name == ap_name :
         if pkt.addr2 not in Probe_info:
            Print("New Probe request--", client_name)
            Print("MAC is --", pkt.addr2)
            Probe_list.append(pkt.addr2)
   print(probe_list)
   
try:
    check = sniff(iface = "Realtek USB GbE Family Controller #2", prn = Probe_info)
    print(check)
except KeyboardInterrupt:
    print('Probe cancelled...') 

'''
import sys
import time

for i in range(10):
    print('[')
    sys.stdout.write("\r{0}>".format("="*i))
    sys.stdout.flush()
    time.sleep(0.5)
    '''