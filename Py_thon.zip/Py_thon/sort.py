# -*coding: utf-8 -*-
"""
Created on Sat Feb 26 09:26:07 2022

@author: SamuelJames
"""

systems = ['PowerDMS','KBB','Avaya Call Recording','Touchpoint','Avaya Communicator','FreshWorks','Spark','Defi','Defi Looker','NLS','Outlook','Teams','PDCFlow','Azure Data Studio','CDK','Goldstar','Fabsoft','Ibeam','SCRA','Clear','TLO','Experian','Transunion','Equifax','SaS Enterprise Guide','Payix','SinglePoint','DataLake','Vanwagenen','Jcap','PowerBI']
systems.sort()

for ind in range(1, len(systems)):
    print(systems[ind])