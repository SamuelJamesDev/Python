# -*- coding: utf-8 -*-
"""
Created on Fri Apr 29 11:56:23 2022

@author: SamuelJames
this is an importable library I have created to query FreshWorks from python using requests

V - 1.3
"""

'''
#Notatation of changes to internal library:
SJ  - added assets to library - 04/15
SJ  - added specify option by ID - 04/26
SJ  - Added non-required conditional arguments for requests: Page and ID - 05/03
'''


import requests 
import json
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
import os

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

api_key = "26suLUhxIvs9IqPG0RFD"
password = "Welcome1"

#loading bar variable
noise = [" ", "🌑 ","🌒 ","🌓 ","🌔 ","🌕 ","🌖 ","🌗 ","🌘 ","🌑 ","🌒 ","🌓 ","🌔 ","🌕 ","🌖 ","🌗 ","🌘 ", "🌑 ","🌒 ","🌓 "]

class FWRQ:
    def __init__(self, url, auth1, auth2):
        self.url = url
        self.auth1 = auth1
        self.auth2 = auth2
    
    def makeIt(self):
        r = requests.get(self.url, auth = (self.auth1, self.auth2), verify=False)
        return r.json()


#"https://drivewayfinancecorp.freshservice.com/api/v2/assets?per_page=100&page="

#generically pull all assets, can add asset ID and tickets page no.
def assetPull(page = None, reqid = None):
    if page is not None:
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/assets' + (page)), api_key, password)
    elif reqid is not None:
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/assets/' + (reqid)), api_key, password)
    else:
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/assets'), api_key, password)
    req = FWRQ.makeIt(p)
    return req

#generically pull all tickets, can add ticket ID and tickets page no.
def ticketPull(page = None, reqid = None):
    if page is not None:
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/tickets' + (page)), api_key, password)
    elif reqid is not None:
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/tickets/' + (reqid)), api_key, password)
    else:
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/tickets'), api_key, password)
    req = FWRQ.makeIt(p)
    return req

#generically pull all requesters, can add requester ID and requester page no.
def requesterPull(page = None, reqid = None):
    if page is not None:
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/requesters' + (page)), api_key, password)
    elif reqid is not None:
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/requesters/' + (reqid)), api_key, password)
    else:
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/requesters'), api_key, password)
    req = FWRQ.makeIt(p)
    return req

#generically pull all agents, can add agent ID and agents page no.
def agentPull(page = None, reqid = None):
    if page is not None:
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/agents' + (page)), api_key, password)
    elif reqid is not None:
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/agents/' + (reqid)), api_key, password)
    else:
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/agents'), api_key, password)
    req = FWRQ.makeIt(p)
    return req

#pull all requester IDs
def reqIds():
    allIds = []
    names = []
    for i in range(1, 20):
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/requesters?page=' + (str(i))), api_key, password)
        req = FWRQ.makeIt(p)
        print(noise[i]*5, end='\r')
        
        try:
            for j in range(1, 80):
                names.append(str(req['requesters'][j]['first_name']) + ' ' + str(req['requesters'][j]['last_name']))
                allIds.append(req['requesters'][j]['id'])
        except IndexError:
            pass
    print(' '*50, end='\r')
    return allIds, names

#Pull all agent IDs
def agentIds():
    names = []
    allIds = []
    for i in range(1, 2):
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/agents?page=' + (str(i))), api_key, password)
        req = FWRQ.makeIt(p)
        print(noise[i]*5, end='\r')
        try:
            for j in range(1, 80):
                names.append(str(req['agents'][j]['first_name']) + ' ' + str(req['agents'][j]['last_name']))
                allIds.append(req['agents'][j]['id'])
        except IndexError:
            pass
    return allIds, names

#Pull all assets
def assetIds():
    names = []
    allIds = []
    for i in range(1, 20):
        p = FWRQ(('https://drivewayfinancecorp.freshservice.com/api/v2/assets?page=' + (str(i))), api_key, password)
        req = FWRQ.makeIt(p)
        print(noise[i]*5, end='\r')
        try:
            for j in range(1, 60):
                names.append(str(req['assets'][j]['name']))
                allIds.append(req['assets'][j]['display_id'])
        except IndexError:
            pass
    return allIds, names

#Specify and pull specific requester or agent pages
def specifyAgent(ids):
    page = agentPull(reqid = str(ids))
    return (page)
    
def specifyRequester(ids):
    page = requesterPull(reqid = str(ids))
    return (page)

def specifyAsset(ids):
    page = assetPull(reqid = str(ids))
    return (page)