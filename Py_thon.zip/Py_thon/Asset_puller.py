# -*- coding: utf-8 -*-
"""
Created on Wed Jan  5 15:14:34 2022

@author: SamuelJames
"""
# Imports______________________________________________________________________
import requests 
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
import time
from colorama import init
from termcolor import colored
from tqdm import tqdm
import pandas as pd
import os
from os import system
# End Imports__________________________________________________________________

# use Colorama to make Termcolor work on Windows too, initialize with init()
init()

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Variables____________________________________________________________________
#API key works, password does not matter
api_key = "26suLUhxIvs9IqPG0RFD"
password = "Welcome1" 
#this can be any made up password, it doesn't actually check

buffspace = '''____________________________________________________'''
endbuff = '''++++++++++++++++++++++++++++++++++++++++++++++++++++'''
assets = []
names = []
ids = []
user = []
location = []
# END Variables________________________________________________________________


# Functions____________________________________________________________________
def convertUsers(user):
    system('cls')
    openPrgm()
    for i in tqdm (range (len(names)), 
               desc="Finding Users...", 
               ascii=False, ncols=75):
        #time.sleep(0.02)
        grabUser(user[i], i)
        
def convertLocation(location):
    system('cls')
    openPrgm()
    for i in tqdm (range (len(names)), 
               desc="Finding Locations...", 
               ascii=False, ncols=75):
        time.sleep(0.02)
        if location[i] == 15000329491 or location[i] == 15000330004:
            location[i] = 'MEDFORD'
        elif location[i] == 15000329490 or location[i] == 15000331122:
            location[i] = 'PORTLAND'
        elif location[i] == 15000329992 or location[i] == 15000331123:
            location[i] = 'REMOTE'
        elif location[i] == 15000329990:
            location[i] = 'REMOTE'
        else:
            location[i] = 'None'
        
def grabUser(req_id, num):
            if(req_id is None):
                return
            try:
                r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/agents/"+
                                  str(req_id), auth = (api_key, password), verify=False)
                data2 = r2.json()
                #print(colored('Asset User Name: ', 'blue', 'on_white'))
                user[num] = (data2['agent']['first_name'] + ' ' + data2['agent']['last_name'])
                if user[num] == None:
                    user[num] = 'None'
            except ValueError:
                r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/"+
                                  str(req_id), auth = (api_key, password), verify=False)
                data2 = r2.json()
                #print(colored('Asset User Name: ', 'blue', 'on_white'))
                try:
                    user[num] = (data2['requester']['first_name'] + ' ' + data2['requester']['last_name'])
                    if user[num] == None:
                        user[num] = 'None'
                except TypeError:
                    print('No User')

def writeToCSV(assets, names, ids, user):
    df = pd.DataFrame({'Asset Owner': user, 
                       'ASSET TAG': assets,
                       'ASSET NAME': names, 
                       'ASSET TYPE': ids, 
                       'ASSET LOCATION': location})
    df.to_csv('INVENTORY.csv', index= False)


def loadbar():
    for i in tqdm (range (100), 
               desc="Compiling Assets...", 
               ascii=False, ncols=75):
        time.sleep(0.02)

def openPrgm():
    logo = '''
    Unified Inventory Collection Organization Recovery Network
    
                \  U.N.I.C.O.R.N. V.2.2.1
                \\
                 \%,     ,'     , ,.
                  \%\,';/J,";";";;,,.
     ~.------------\%;((`);)));`;;,.,-----------,~
    ~~:           ,`;@)((;`,`((;(;;);;,`         :~~
   ~~ :           ;`(@```))`~ ``; );(;));;,      : ~~
  ~~  :            `X  (( `),    (;;);;;;`       :  ~~
 ~~~~ :            / `) `` /;~   `;;;;;;;);,     :  ~~~~
~~~~  :           / , ` ,/` /     (`;;(;;;;,     : ~~~~
  ~~~ :          (o  /]_/` /     ,);;;`;;;;;`,,  : ~~~
   ~~ :           `~` `~`  `      ``;,  ``;" ';, : ~~
    ~~:                             `'   `'  `'  :~~
     ~`-----------------------------------------`~
    '''
    print(logo)

def compileAssets(data):
    for i in range(370):
        if data['assets'][i]['name'] is not None:    
            #print(data['assets'][i]['name'])
            names.append(data['assets'][i]['name'])
            assets.append(data['assets'][i]['asset_tag'])
            ids.append(data['assets'][i]['asset_type_id'])
            user.append(data['assets'][i]['user_id'])
            location.append(data['assets'][i]['location_id'])

def grabInv(page):
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/assets?per_page=100&page=" + 
                     str(page), auth = (api_key, password), verify=False)
    #print(r)
    if r.status_code == 200:
        try:
            data = r.json()
            #print(data)
            compileAssets(data)
            
        except IndexError:
            print(colored('REACHED END OF INVENTORY PAGE' + 
                          str(page), 'white', 'on_grey'))
    else:
        if page != 0:
            print("Failure to access site for page: " + str(page))

def conVal(names, assets, ids, location):
    convertLocation(location)
    convertUsers(user)
    #for i in range(len(names)):
    #    print(buffspace)
    #    print('Asset Name: ' + str(names[i]) + 
    #          '\nAsset Tag: ' + str(assets[i]) + 
    #          '\nAsset Type ID: ' + str(ids[i]) + 
    #          '\nCurrent User: ' + str(user[i]) + 
    #          '\nCurrent Location: ' + str(location[i]))
    #    print(buffspace)

def calcTotals(names, assets, ids):
    i = 0
    j = 0
    k = 0
    l = 0
    m = 0
    n = 0
    X = 0
    count = 0
    print('\n\n' + str(len(assets)) + 
          ' Available Assets are currently in the inventory')
    print(endbuff)
    for d in ids:
        if d == 15000917364:#
            i+=1
            ids[count] = 'LAPTOP'
        elif d == 15000917363:#
            j+=1
            ids[count] = 'DESKTOP'
        elif d == 15000917351:#
            k+=1
            ids[count] = 'MONITOR'
        elif d == 15000917342:#
            l+=1
            ids[count] = 'KEYBOARD AND MOUSE'
        elif d == 15000930680:#
            m+=1
            ids[count] = 'USB-C DOCK'
        elif d == 15000917359:#
            n+=1
            ids[count] = 'WEBCAM'
        elif d == 15000940906:#
            X+=1
            ids[count] = 'HEADSET'
        count+=1   

    print(i, ' LAPTOPS\n')
    print(j, ' PRODESKS\n')
    print(k, ' MONITORS\n')
    print(l, ' KEYBOARDS AND MICE\n')
    print(m, ' USB-C DOCKS\n')
    print(n, ' WEBCAM\n')
    print(X, ' HEADSETS\n')
    
    print("TOTAL = " , (i+j+k+l+m+n+X))
#END Functions_________________________________________________________________

# Run Program__________________________________________________________________
try:
    openPrgm() #cool unicorn logo

    #We should have at least 4 pages of inventory
    loadbar()
    for i in range(5):
        grabInv(i)
        
    conVal(names, assets, ids, location)
    #convertUsers(user)
    
    #elif count each type
    calcTotals(names, assets, ids)
    print(endbuff)
    writeToCSV(assets, names, ids, user)
    #print(user)
    print(colored('Inventory Available Here: ' + 
                  os.getcwd(), 'white', 'on_green'))
    #findUnused()
    # END Run Program__________________________________________________________
except KeyboardInterrupt:
    print("GOODBYE")