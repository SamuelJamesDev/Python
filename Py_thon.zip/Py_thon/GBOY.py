# -*- coding: utf-8 -*-
"""
Created on Thu Mar 31 15:40:07 2022

@author: SamuelJames
"""

from tkinter import *
import subprocess
from datetime import date
from ttkthemes import ThemedStyle
from tkinter import PhotoImage, Tk, Canvas, Button, Label
import time

def run(event):
    command = cmd.get('1.0', 'end').split('\n')[-2]
    
    if str(command) == 'date':
        cmd.insert('end', f'\n' + str(date.today()))
    elif str(command) == 'clear':
        delete()
    else:
        cmd.insert('end', f'\n{subprocess.getoutput(command)}')
    #subprocess.Popen(command)

def esc(event):
    exit()
    
def delete():
   cmd.delete("1.0","end")

def A(event):
    cmd.insert('A')
    
def B(event):
    cmd.insert('B')
   
try:
    
    root = Tk()
    root.title("R34P3R Terminal")
    canvas = Canvas(root, width=900, height=500)
    canvas.pack()
    photo = PhotoImage(file="RES/gboy.PNG")
    canvas.create_image(450, 250, image=photo)
    
    btnA = PhotoImage(file = "RES/A.PNG")
    btnB = PhotoImage(file = "RES/B.PNG")
    startBtn = PhotoImage(file = "RES/start.PNG")
    
    start_button = Button(root, image=startBtn, command=root.quit, anchor='w', highlightthickness = 0, bd = 0)
    start_button_window = canvas.create_window(125, 275, anchor='nw', window=start_button)    

    A_button = Button(root, image=btnA, command=A, anchor='w', highlightthickness = 0, bd = 0)
    A_button_window = canvas.create_window(770, 155, anchor='nw', window=A_button)
    
    B_button = Button(root, image=btnB, command=B, anchor='w', highlightthickness = 0, bd = 0)
    B_button_window = canvas.create_window(700, 175, anchor='nw', window=B_button)
    
    cmd = Text(root, height = 15, width = 60, bg = 'cyan')
    cmd_window = canvas.create_window(225,100 , anchor='nw', window=cmd)

    cmd.bind('<Return>', run)
    cmd.bind('<Escape>', esc)

    root.mainloop()
    
except KeyboardInterrupt:
    print('goodbye')