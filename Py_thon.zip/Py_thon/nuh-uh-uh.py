# -*- coding: utf-8 -*-
"""
Created on Wed May 11 15:41:45 2022

@author: SamuelJames

NUH-UH-UHHHHHH
"""

import os
import time


g1 = ("""

                                   ._ o o
                                   \_`-)|_
                                ,""       \ 
                              ,"  ## |   ಠ ಠ. 
                            ," ##   ,-\__    `.
                          ,"       /     `--._;)
                        ,"     ## /
                      ,"   ##    /


                """)

g2 = ("""

                                   ._ o o
                                   \_`-)|_
                                ,""       \ 
                              ,"  ## |   ಠ ಠ. 
                            ," ##   ,-\__    `.
                          ,"       /     `--._;) GET
                        ,"     ## /
                      ,"   ##    /


                """)

g3 = ("""

                                   ._ o o
                                   \_`-)|_
                                ,""       \ 
                              ,"  ## |   ಠ ಠ. 
                            ," ##   ,-\__    `.
                          ,"       /     `--._;) GET FUCKED...
                        ,"     ## /
                      ,"   ##    /


                """)
giraf = []
                
giraf.append(g1)
giraf.append(g2)
giraf.append(g3)

for i in range(5):
    for i in range(len(giraf)):
        print(giraf[i])
        time.sleep(1)
        os.system('cls')