#! /usr/bin/env python
#from scapy.all import *
'''
def arp_monitor_callback(pkt):
    if ARP in pkt and pkt[ARP].op in (1,2): #who-has or is-at
        return pkt.sprintf("%ARP.hwsrc% %ARP.psrc%")

check = (sniff(prn=arp_monitor_callback, filter="arp", store=0))
print(check)
'''
'''import nmap
nm = nmap.PortScanner()
data = nm.scan(hosts="192.168.2.1/24", arguments="-sP")
print([ip for ip, result in data['scan'].iteritems() if result['status']['state'] == 'up'])
'''

#pip install pdfminer.six
import io
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage
import xml.etree.ElementTree as ET
from bs4 import BeautifulSoup 
from docx2pdf import convert
from docx import Document

def convert_pdf_to_txt(path):
    '''Convert pdf content from a file path to text

    :path the file path
    '''
    rsrcmgr = PDFResourceManager()
    codec = 'utf-8'
    laparams = LAParams()

    with io.StringIO() as retstr:
        with TextConverter(rsrcmgr, retstr, codec=codec,
                           laparams=laparams) as device:
            with open(path, 'rb') as fp:
                interpreter = PDFPageInterpreter(rsrcmgr, device)
                password = ""
                maxpages = 0
                caching = True
                pagenos = set()

                for page in PDFPage.get_pages(fp,
                                              pagenos,
                                              maxpages=maxpages,
                                              password=password,
                                              caching=caching,
                                              check_extractable=True):
                    interpreter.process_page(page)
                return retstr.getvalue()

def create_xml(that):
        usrconfig = ET.Element("usrconfig")
        usrconfig = ET.SubElement(usrconfig,"data_stuff")
        for thing in range(len(that)):
                usr = ET.SubElement(usrconfig,"data"+str(thing))
                usr.text = str(that[thing])
        tree = ET.ElementTree(usrconfig)
        tree.write("details.xml",encoding='utf-8', xml_declaration=True)

def verify_xml():
    with open('details.xml', 'r') as f:
        data = f.read() 
    print(data)
    f.close()

def create_docx(xml):
    document = Document()
    document.add_paragraph(xml)
    document.save('test.docx')

def create_pdf(filename):
    convert(filename)
    convert(filename, "TESTING.pdf")
    print("pdf converted.")
    
if __name__ == "__main__":
    that = convert_pdf_to_txt('Test.pdf')
    that = that.replace("\n", " ")
    print(that)
    th = list(that.split())
    print(th)
    create_xml(th)
    verify_xml()
    create_docx(th)
    create_pdf('test.docx')