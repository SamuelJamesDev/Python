# -*- coding: utf-8 -*-
"""
Created on Tue Mar 29 11:15:18 2022

@author: SamuelJames
"""

import requests 
import json
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

api_key = "Samuel James"
password = "YogaBall123!"

def grabUser(req_id):
            if(req_id is None):
                print('No User exists yet')
                return
            r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/solutions/articles/", auth = (api_key, password), verify=False)
            #r2 = requests.get("https://socascades.defisolutions.com/", auth = (api_key, password), verify=False)
            #r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/applications?search=\"name%3A%27Avaya%27\"", auth = (api_key, password), verify=False)
            #data = r2.json()
            print(r2.content)    
    
                    
grabUser((15002194184))