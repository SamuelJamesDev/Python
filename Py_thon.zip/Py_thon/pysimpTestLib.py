# -*- coding: utf-8 -*-
"""
Created on Thu May 12 09:27:24 2022

@author: SamuelJames
"""

import simptest

check = True
ran = 10

for i in range(10):
    if i != 10:
        print(i)
        simptest.CircleLoad(check, ran)

check = False