# -*- coding: utf-8 -*-
"""
Created on Fri Feb 11 11:35:33 2022

@author: SamuelJames
"""

# Imports______________________________________________________________________
import requests 
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
import time
from colorama import init
from termcolor import colored
from tqdm import tqdm
# End Imports__________________________________________________________________

# use Colorama to make Termcolor work on Windows too, initialize with init()
init()

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Variables____________________________________________________________________
#API key works, password does not matter
api_key = "26suLUhxIvs9IqPG0RFD"
password = "Welcome1" 
#this can be any made up password, it doesn't actually check

buffspace = '''____________________________________________________'''
endbuff = '''++++++++++++++++++++++++++++++++++++++++++++++++++++'''
assets = []
noname = []
noname_other = []
ids = []
noname_ids = []
# END Variables________________________________________________________________


# Functions____________________________________________________________________
def loadbar():
    for i in tqdm (range (100), 
               desc="Compiling Assets...", 
               ascii=False, ncols=75):
        time.sleep(0.02)

def openPrgm():
    logo = '''
    Danger...
    My Assets are Unamed Mr. Robinson!
    
    ,.-""``""-.,
    /  ,:,;;,;, | 
    |/  ';';;';'|
     `'---;;---'`
     <>_==""==_<>
     _<<<<<>>>>>_
   .'____\==/____'.
   |__   |__|   __|
  /C  \  |..|  /  D|
  \_C_/  |;;|  \_c_/
   |____o|##|o____|
    \ ___|~~|___ /
     '>--------<'
     {==_==_==_=}
     {= -=_=-_==}
     {=_=-}{=-=_}
     {=_==}{-=_=}
     }~~~~""~~~~{
     }____::____{
    /`    ||    `|
    |     ||     |
    |     ||     |
    '-----''-----'
     ~`-----------------------------------------`~
    '''
    print(logo)

def grabInv(page):
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/assets?per_page=100&page=" + 
                     str(page), auth = (api_key, password), verify=False)
    #print(r)
    if r.status_code == 200:
        try:
            data = r.json()
            #print(data)
            for i in range(100):
                #print(data['assets'][i]['asset_type_id'])
                check = checkAsset(data['assets'][i]['asset_type_id'])
                if(check):
                    if data['assets'][i]['description'] is None or data['assets'][i]['description'] == '' or len(str(data['assets'][i]['description'])) > (15):
                        assets.append(data['assets'][i]['name'])
                        ids.append(data['assets'][i]['id'])
                    else:
                        assets.append(data['assets'][i]['description'])
                        ids.append(data['assets'][i]['id'])
                        #print("TRUE!")
        except IndexError:
            print(colored('REACHED END OF INVENTORY PAGE' + 
                          str(page), 'white', 'on_grey'))
    else:
        if page != 0:
            print("Failure to access site for page: " + str(page))
            
def grabInv2(page, name):
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/assets?per_page=100&page=" + 
                     str(page), auth = (api_key, password), verify=False)
    #print(r)
    if r.status_code == 200:
        try:
            data = r.json()
            #print(data)
            for i in range(100):
                if(data['assets'][i]['id'] == name):
                    print(data['assets'][i])
                    print(data['assets'][i]['asset_tag'])
                    print(data['assets'][i]['user_id'])
                    print(data['assets'][i]['name'])
                    print(data['assets'][i]['created_at'])
                    print(buffspace)
                
        except IndexError:
            print(colored('MATCHED\n\n', 'white', 'on_cyan'))
    else:
        if page != 0:
            print("Failure to access site for page: " + str(page))

def checkAsset(d):
    if d == 15000917364:
        #do the thing
        #print("laptop")
        return True
    elif d == 15000917363:
        #do the thing'
        #print("laptop")
        return True
    else:
        #print("NOT A COMPUTER")
        return False

def find_possible_IDs(names):
    for i in range(6):
        grabInv2(i, names)
        
#END Functions_________________________________________________________________

# Run Program__________________________________________________________________
try:
    openPrgm() #cool unicorn logo

    #We should have at least 4 pages of inventory
    loadbar()
    for i in range(6):
        grabInv(i)
    for i in range(len(assets)):
        if assets[i].find('ORMED') == -1 and assets[i].find('ORLIT') == -1 and assets[i].find('ORPOR') == -1 and assets[i].find('-') == -1:
            noname.append(assets[i])
            noname_ids.append(ids[i])
            #print(assets[i])
    for i in range(len(noname)):
        print(noname[i])
    print(endbuff)
    for d in noname_ids:
        find_possible_IDs(d)
    print("FINISHED")
    # END Run Program__________________________________________________________
except KeyboardInterrupt:
    print("GOODBYE")