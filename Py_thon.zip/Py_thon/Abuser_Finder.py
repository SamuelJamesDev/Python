'''
Author: Samuel James
Use: This program will scrape through multiple tickets and users to 
     identify people who put in erronious tickets 
Date: 2/3/2022
Name: Abuser_Finder.py
'''

import requests 
import json
from bs4 import BeautifulSoup
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
import time
from colorama import init
from termcolor import colored
from collections import Counter
import pandas as pd

'''
Urgency Glossary:
    1 = Low
    2 = Medium
    3 = High
    4 = Urgent
'''

# use Colorama to make Termcolor work on Windows too
init()

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

#___________________________________________________________Variables
#Program Logo
def openPrgm():
    logo = '''
    O.R.I.G.A.M.I - T.A.
    Order, Rank, Iterate and Generate Metrics for Internal Ticket Abuses 
        _____                   /|
        |   \      ____        / |
  __    |    \    /\   |      /  ;
 /\  \  |     \  /  \  |     /  ;
/,'\  \ |      \/  : \ |    /   ;
~  ;   \|      /   :  \|   /   ;
   |    \     /   :'  |   /    ;
   |     \   /    :   |  /    ;
   |      \ /    :'   | /     ;
   |       /     :    |/     ;
   |      /     :'    |      ;
    \    /      :     |     ;
     \  /      :'     |     ;
      \       :'      |    ;
       \______:_______|___;
    '''
    print(colored(logo, 'cyan'))
    time.sleep(2)


api_key = "26suLUhxIvs9IqPG0RFD"
password = "Biggie556!"

ticket_list = []
users = []
ticket_nums = []
date = []
prty = []
#___________________________________________________________Functions

#retrieve the int amount of tickets to search through
def getSearchInt():
    inp = input("Enter The # tickets to search through....\n")
    return int(inp)

def getHighestTicket():
    #generate a request for the tickets page
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/tickets/", 
                     auth = (api_key, password), verify=False)
    print(colored("Retrieving highest ticket number, the response is given below\n", 'white', 'on_cyan') + 
          str(colored(r.status_code, 'white', 'on_green')))
    #If 200 <GOOD> response is received, parse into JSON data
    data = r.json()
    
    #this method allows me to return only the ticket ID through JSON, which I can now set to the highest ticket number 
    print(colored("HIGHEST TICKET NUMBER: ", 'white', 'on_cyan'))
    print(data['tickets'][0]['id'])
    print("Each Dot represents one ticket that has been pulled")
    top_ticket = data['tickets'][0]['id']
    
    #Return and assign highest ticket number for reverse searching
    return top_ticket

#retrieve users by name regardless of whether the user an agent or requester
def grabUser(req_id):
            #if no user ID exists return and continue iterating through tickets
            if(req_id is None):
                print('No User exists yet')
                return
            #try grabbing from agents, except index error and search requesters
            try:
                r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/agents/"+
                                  str(req_id), auth = (api_key, password), verify=False)
                #parse to JSON
                data2 = r2.json()
                #grab name from JSON parsing
                name = (data2['agent']['first_name'] + ' ' + data2['agent']['last_name'])
                #add to our list of users
                users.append(name)
                
            except ValueError:
                #Not an agent
                r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/"+
                                  str(req_id), auth = (api_key, password), verify=False)
                #pull data2 and parse from JSON
                data2 = r2.json()
                try:
                    #parse name from JSON and add to our list of users
                    name = (data2['requester']['first_name'] + ' ' + 
                            data2['requester']['last_name'])
                    users.append(name)

                except TypeError:
                    #Show that a snag has been hit and a username must be replaced
                    #print('\nFailed to grab data2 User page... Appending No Name')
                    users.append(data2['requester']['first_name'])
                print('.', end=" ")

#grab the subject of each ticket to append to the list of tickets to count
def grabTickets(ticket_num):
    #appe
    ticket_nums.append(str(ticket_num))
    #Run request for ticket URL
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/tickets/"+str(ticket_num), auth = (api_key, password), verify=False)
    
    #If 200 <GOOD> response is received, parse into JSON data and grab ticket
    data = r.json()
    #print(data)
    if r.status_code == 200:
        soup = BeautifulSoup(r.content, 'html.parser')
        try:
            #1st attempt to grab ticket info from BS4
            rows = soup.select("div",{"id": "ticket_original_request"})[0].text.strip().replace('\\n', ' ')
            ticket_list.append(data['ticket']['subject'])
            prty.append(data['ticket']['urgency'])
            date.append(data['ticket']['created_at'])
            req_id = data['ticket']['requester_id']
            grabUser(req_id)

        except IndexError:
            #If IndexError received attempt trying to read the H2 header
            rows = str(soup.select("h2"))#, {"class": "subject"}))
            if(rows == '[]' or rows == None):
                #If you cannot pull H2 parse from JSON
                ticket_list.append(data['ticket']['subject'])
                prty.append(data['ticket']['urgency'])
                date.append(data['ticket']['created_at'])
                req_id = data['ticket']['requester_id']
                grabUser(req_id)
            else:
                print("Ticket Parsing Failure Error for ticket: [" + str(ticket_num) + ']')
    else:
        print("Failed to read ticket: ["+ str(ticket_num) + ']')

def compile_users(srchNum):
    #retrieve highest ticket
    i = getHighestTicket()
    #set iteration variable
    y = 0
    #grab each ticket, which grabs each user for compilation
    while y < srchNum:
        grabTickets(i)
        i -= 1    
        y += 1

#simple pandas dataframe to turn appended values into a csv
def writeToCSV(user, tickets, nums):
    df = pd.DataFrame({'Ticket Creator': user, 
                       'Ticket Description': tickets,
                       'Ticket Number' : nums,
                       'Date Created' : date, 
                       'Urgency' : prty})
    df.to_csv('Tickets.csv', index= False)
    
#Run Program
openPrgm()

#try catch for Keyboard Exceptions for gracefully exiting
try:
    # get number of tickets to reverse search through
    srchNum = getSearchInt()
    
    # Iterate through all tickets/users
    compile_users(srchNum)
    
    #print basic information relating to the fully run pprogram
    final_users = Counter(users)
    final_tickets = Counter(ticket_list)
    
    print("\n\nTOP USERS AND THEIR NUMBER OF TICKETS: ")
    for usr in final_users:
        print(usr, ': ', final_users[usr])
        
    print("\n\nTOP TICKET SUBJECTS AND NUMBER OF TICKETS WITH THE GIVEN SUBJECT: ")
    for tic in final_tickets:
        print(tic, ': ', final_tickets[tic])
    #print(Counter(users))
    #print(Counter(ticket_list))
    #print(users)
    print("\n\nUser length: ", len(users))
    print("ticket length: ", len(ticket_list))
    
    #write each list value into csv format for review
    writeToCSV(users, ticket_list, ticket_nums)
    
except KeyboardInterrupt:
    print('Program Closed...')