# -*- coding: utf-8 -*-
"""
Created on Tue May 31 15:08:46 2022

@author: SamuelJames
"""

#THIS IS JUST MEANINGFUL TOO ME.

print("""The most alarming aspect of the DMCA for hackers is that it embodies
the fallacy that the only sources of innovation of benefit to society lie
within the halls of research institutions and corporations. Suddenly, it is a
crime to explore, in the comfort of your own home in pursuit of your
hobby, the cryptographic methods used to secure access rights. Restricting the research of such technology to only established institutions
disallows the possibility of technology development by unaffiliated
individuals. Without the freedom to research and develop technology in
their own garage, where would the likes of Bill Hewlett and Dave
Packard, or Steve Jobs and Steve Wozniak be today? Would we have
Linux and netBSD if the right of hackers to express themselves freely in
code was regulated?""")

print("""\n ci-pher n): 1 a: ZERO b: one that has no weight, worth, or influence : NONENTITY. 2 a: a method of transforming text in order to
conceal its meaning — compare to CODE 2""")


"""This message is for the people I lost. You may be gone but there isn't a day I don't think of you guys. It should have been me. It always should have been me.
Given the time to really look at the accidents, firefights whatever the fuck happened it's hard not feel empty. Like I missed out on dying. I came back for what? 
TO sit and wonder if I would be better as some vague memorial than a man. Life takes away the people who do the most sometimes I swear. I guess that is why in turn I
am the one left here. With memories of violence and the taste of copper pennies. It's weird to plan on dying and still be alive. I never pictured myself as such a dragged out 
play. A sonata with no intermission but a heaping of mediocrity. Life is a bitch and then you die, unless you don't. Then you are left with regret, guilt and wonder.
I haven't slept right in 5 years. Sometimes I picture things and I can't tell if it's real or not with how vivid I can see it. I miss you. I wasn't supposed to still be here
and now I am, here. Waiting for my turn. I can only hope I can make the memory of all of yuou proud."""