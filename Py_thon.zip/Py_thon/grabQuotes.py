# -*- coding: utf-8 -*-
"""
Created on Fri Feb 18 12:02:56 2022

@author: SamuelJames
"""

import requests 
import json
import urllib3
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def Grab_Quotes():
    r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/?per_page=100&page=", verify=False)
    data = r2.json()
    print(data)

Grab_Quotes()