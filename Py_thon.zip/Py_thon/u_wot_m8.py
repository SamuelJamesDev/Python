# -*- coding: utf-8 -*-
"""
Created on Thu Apr  7 15:17:15 2022

@author: SamuelJames
"""
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

key = 'Yjg4ZGU1MjktZGNjZS0xY2E0LWY3M2UtYzQ0NjAxZDU0MGMwd2Y3M2VjNDQ2LTAxZDUtNDBjMC1iODhkLWU1MjlkY2NlMWNhNHcwOGMxM2JiOS1mZTJhLWJmNDAtNDc3Mi0xYWQ2MjMzMWUzNWM='
password = 'YogaBall123!'

headers = {
    'User-Agent': 'IE',
}

r = requests.get('http://199.193.73.102:9080/', headers=headers, auth = (key, password), verify=False)
print(r.status_code)
print(r.text)