# -*- coding: utf-8 -*-
"""
Created on Fri Mar 25 09:19:28 2022

@author: SamuelJames
"""

import requests 
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

api_key = "26suLUhxIvs9IqPG0RFD"
password = "Welcome1"

r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/purchase_orders?per_page=100", auth = (api_key, password), verify=False)

data = r.json()

print(data)