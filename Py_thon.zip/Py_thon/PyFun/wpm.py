# -*- coding: utf-8 -*-
"""
Created on Tue Nov 23 08:35:56 2021

@author: SamuelJames
"""

from time import time
from random import randrange
i = 0
cs = False
prompt = ['The quick brown fox jumps over the lazy dog', 
          'If you can read this you are way too close',
          'Waltz, bad nymph, for quick jigs vex.',
          'How vexingly quick daft zebras jump!',
          'Jackdaws love my big sphinx of quartz.',
          'Pack my box with five dozen liquor jugs.',
          'Glib jocks quiz nymph to vex dwarf.']

def counter(num):
    i = 0 
    print(prompt[num])
    input(">> Press ENTER to begin")
    begin_time = time()
    inp = input("\n")
    end_time = time()
    final_time = (end_time - begin_time) / 60
    return final_time, inp


def wpm(time, line):
    words = line.split()
    word_length = len(words)
    words_per_m = word_length / time
    return words_per_m


def wordcheck(inp, num):
    prompts = prompt[num].split()
    inputs = inp.split()
    errorcount = 0
    correct = 0
    for i in range(len(inputs)):
        if inp[i] != prompts[i]:
            errorcount += 1
        if inp[i] == prompts[i]:
            correct += 1

    words_left = len(prompts) - len(inputs)
    print("wleft ", words_left)
    numCorrect = float(len(prompts)) - float(errorcount)
    print("Correct: ", numCorrect)
    percentage = (((float(numCorrect) / float(len(prompts))) - float(words_left) / float(len(prompts))) * 100)

    return percentage

random_index = randrange(len(prompt))
tm, line = counter(random_index)
tm = round(tm, 2)
words_per_minute = wpm(tm, line)
words_per_minute = round(words_per_minute, 2)
print("You total time was:", tm, " minutes")
print("with an average of: ", words_per_minute, " words per minute")
percentage = wordcheck(line, random_index)
print(line)
#percentager = round(percentage, 2)
print("with an accuracy of: ",  percentage, "% accuracy")