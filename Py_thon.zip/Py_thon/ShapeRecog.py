# -*- coding: utf-8 -*-
"""
Created on Tue Apr 19 14:04:29 2022

@author: SamuelJames
"""

import matplotlib.pyplot as plt
import numpy as np
import cv2
from tkinter import filedialog


try:
    imName = filedialog.askopenfilename()
except AttributeError:
    print("no image chosen")
    exit()
    
# load the image and then display original
image = cv2.imread(imName)
plt.imshow(image)
plt.show()


# convert the color image into grayscale
grayScale = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Find edges in the image using canny edge detection method
sigma = 0.33
# Calculate lower threshold and upper threshold using sigma = 0.33
v = np.median(grayScale)
low = int(max(0, (1.0 - sigma) * v))
high = int(min(255, (1.0 + sigma) * v))
# create edged variable 
edged = cv2.Canny(grayScale, low, high)

# After finding edges we have to find contours
# Contour is a curve of points with no gaps in the curve
# It will help us to find location of shapes

# cv2.RETR_EXTERNAL is passed to 
# find the outermost contours (because we want to outline the shapes)
# cv2.CHAIN_APPROX_SIMPLE is removing redundant points along a line
(cnts, _) = cv2.findContours(edged,
                                cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)


'''
use a contour approximation method (detectshape method) to find the vertices of geometric shapes. 
This alogrithm is also known as Ramer Douglas Peucker alogrithm.
In OpenCV it is implemented in cv2.approxPolyDP method.abs
detectShape() function below takes a contour as parameter and
then returns its shape
'''


def detectShape(cnt):
    shape = 'unknown'
    # calculate perimeter using
    peri = cv2.arcLength(c, True)

    # apply contour approximation and store the result in vertices
    vertices = cv2.approxPolyDP(c, 0.01 * peri, True)

    # If the shape it triangle, it will have 3 vertices
    if len(vertices) == 3:
        shape = 'triangle'

    # if the shape has 4 vertices, it is either a square or rectangle
    elif len(vertices) == 4:

        # using the boundingRect method calculate the width and height
        # of enclosing rectange and then calculte aspect ratio
        x, y, width, height = cv2.boundingRect(vertices)
        aspectRatio = float(width) / height

        # a square will have an aspect ratio that is approximately
        # equal to one, otherwise, the shape is a rectangle
        if aspectRatio >= 0.95 and aspectRatio <= 1.05:
            shape = "square"
        else:
            shape = "rectangle"

    # if the shape is a pentagon, it will have 5 vertices
    elif len(vertices) == 5:
       shape = "pentagon"

    # if the shape is a polygon, it will have 8 vertices
    elif len(vertices) == 6:
        shape = "polygon"
    
    elif len(vertices) == 0:
        shape = "circle"

    # otherwise, we assume the shape is a circle
    else:
      shape = "unknown"
        

    # return the name of the shape
    return shape


# Now we loop over every contour
# call detectShape() for each contour then
# write the name of shape in the center of image

# loop over the contours
for c in cnts:
    # compute the moment of contour
    M = cv2.moments(c)
    # From moment we can calculte area, centroid etc
    # The center or centroid can be calculated as follows
    if M["m00"] != 0:
      cX = int(M["m10"] / M["m00"])
      cY = int(M["m01"] / M["m00"])
    else:
    # set values as what you need in the situation
      cx = 0
      cy = 0
      for p in cnts:
        cx += p[0][0]
        cy += p[0][0]
      cx = int(cx/len(cnts))
      cy = int(cy/len(cnts))

    # call detectShape for contour c
    shape = detectShape(c)

    # Outline the contours
    cv2.drawContours(image, [c], -1, (255, 0, 0), 2)

    # cX-75 will set text to far left
    drawP = cX-50 ## self-note: gotta be a better way than this!!!!!##

    # Write the name of shape on the leftmost point of shapes
    cv2.putText(image, shape, (drawP, cY), cv2.FONT_HERSHEY_SIMPLEX,
                .50, (0, 0, 0), 1)

    # show the output image
    ## self-note: cv2 imshow and findContours not working following cv2's recent update##
plt.imshow(image)
plt.show()