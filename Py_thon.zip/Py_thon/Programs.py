# -*- coding: utf-8 -*-
"""
Created on Wed Mar 23 14:29:09 2022

@author: SamuelJames
"""

'''
Author: Samuel James
Use: This program will run simple networking commands from a CLI GUI
Date: 11/16/21
Name: net.py
 
'''
import emoji
import subprocess
import time
from pyfiglet import Figlet
from colorama import init


# use Colorama to make Termcolor work on Windows too
init()

menu = '''

   _.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._
.-'---      - ---     --     ---   -----   - --       ----  ----   -     ---`-.
+        E - Show some emojis                                          +
+        1 - Animate a gif in ascii                                           +
+        2 - Animate a png in ascii                                           +
+        3 - View a ticket from CLI                                           +
+        4 - Display all FW Scores                                            +
+        5 - Show what happened in history today                              +
+        6 - Run a speed test                                                 +
+        7 - Generate a random Ascii meme                                     +
+        8 - Scrape Email by Subject                                          +
+        8 - Scrape Tickets by Subject                                        +
+        0 - EXIT PROGRAM                                                     +
(___       _       _       _       _       _       _       _       _       ___)
    `-._.-' (___ _) (__ _ ) (_   _) (__  _) ( __ _) (__  _) (__ _ ) `-._.-'
            `-._.-' (  ___) ( _  _) ( _ __) (_  __) (__ __) `-._.-'
                    `-._.-' (__  _) (__  _) (_ _ _) `-._.-'
                            `-._.-' (_ ___) `-._.-'
                                    `-._.-'

'''

logo = '''
::::::::::::::::::::::::::::::::::::::::::::::::::::::--|--:::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::--#|-::-----:--:::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::------:------%xs#s#&&_--%@---:::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::--|_*%@@_%%_@@#xxxxxxxxs_%#x_%|--:::::::::::::::::
::::::::::::::::::::--------------------:@xxsxx#sxxxxxxxxxxxxxxxxxxxxs_:-:::::::::::::::::
:::::::::::::::::::-:||||||||||||||||||*&xxxxxxxxxxxxxxxxxxxxxxxxxxxx@--::::::::::::::::::
:::::::::::::::::::-%|::::::::::::::::%xxxxxxxxxxxxxxxxxxxxxxxxxxxxx@:---:::::::::::::::::
:::::::::::::::::::-%:------------:%-%xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx_:@:-:::::::::::::::::
:::::::::::::::::::-R:------------&s%xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs&--:::::::::::::::::
::::::::::::::::::--U-----------@|#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx*-::::::::::::::::::
:::::::::::::::::-:-N-----------@ssxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx:-::::::::::::::::::
:::::::::::::::::-:-------------:sxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx%--::::::::::::::::::
:::::::::::::::::--|M------------%xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx*-:::::::::::::::::::
:::::::::::::::::-*_Y----------%#xxxxxxxxxxxxxxxxxxxxxxx@&xxxxxxxxxxs|-:::::::::::::::::::
:::::::::::::::::-----:------:_sxxxxxxxxxxxxxxxxxxxxxxxx@|%#xxxxxxxx#*-:::::::::::::::::::
:::::::::::::::::--:P|*:-----|_sxxxxxxxxxxxxxxxxxxxxxx#_x@*:#xxxxxxs%--:::::::::::::::::::
:::::::::::::::::-:-R_*------:sxxxxxxxxxxxxxxxxxxxxxs%#&*---&xxxxx@*|-::::::::::::::::::::
:::::::::::::::::---O:-:-----_xxxxxxxxxxxxxxxxxxxxxx&*_:--:||@s&_|-*|-::::::::::::::::::::
:::::::::::::::::-*:G-*:-----_xxxxxxxxxxxxxxxxxxxxxxs_---:_%--:|::-*|-::::::::::::::::::::
:::::::::::::::::---R--------:_xxxxxxxxxxxxxxxxxxxx_%|---%%:----:*:*|-::::::::::::::::::::
::::::::::::::::::--A*--------*xxxxxxxxxxxxxxxxxxxx_-------------|:*|--:::::::::::::::::::
:::::::::::::::::-:-M_:-------&xxxxxxxxxxxxxxxxxxx#:------------:|-*|:::-:::::::::::::::::
:::::::::::::::::---S------|_&xxxxxxxxxxxxxx&sxxxxs|:------------::***|:-:::::::::::::::::
::::::::::::::::::--**-----:*xxxxxxxxxxxxxxx%|&xxxxs%:-----------|**|:--::::::::::::::::::
::::::::::::::::::---------:&xxxxxxxxxxxxxxx@:-%#sxs&%:----------*:*|-::::::::::::::::::::
:::::::::::::::::--|@*|----|#sxxxxxxxxxxxxxxs*--:|@:-------------|-*|-::::::::::::::::::::
:::::::::::::::::-|_|_%-----|#&xxxxxxxxxxxxxxs_||**|:------------*-*|-::::::::::::::::::::
:::::::::::::::::-::*_:--------@xxxxxxxxxxxxxxxxx%::|:-----------|:*|-::::::::::::::::::::
::::::::::::::::::-|*-------:_@sxxxxxxxxxxxxxxxxs@|--::----------*|*|-::::::::::::::::::::
::::::::::::::::::--:-------|_#xxxxxxxxxxxxxxxx*_--------:|||****|-*|-::::::::::::::::::::
:::::::::::::::::::-%:---------:_&xxxxxxxxxxx%|-:-------||::-------*|-::::::::::::::::::::
:::::::::::::::::::-%:-----------%s#&@_%%%@#@***|||||:::|----------*|-::::::::::::::::::::
:::::::::::::::::::-%:-----------:_---------:::::::::::|||||:------*|-::::::::::::::::::::
:::::::::::::::::::-%:------------%|-----------------------:|------*|-::::::::::::::::::::
:::::::::::::::::::-%:------------@x@|--------------------:||||:---*|-::::::::::::::::::::
:::::::::::::::::::-%:----------:&xxxx&*-----------------::--*@|---*|-::::::::::::::::::::
:::::::::::::::::::-%:----------@xxxxxxx&*--------------:|--*%:----*|-::::::::::::::::::::
:::::::::::::::::::-%:--------|#xxxxxxxxxx#%:--:-------:|-:%|------*|-::::::::::::::::::::
:::::::::::::::::::-%:-------*sxxxxxxxxxxxxxs_:::------|::*:-------*|-::::::::::::::::::::
:::::::::::::::::::-%:------%xxxxxxxxxxxxxxxxxx@*|:----*|::||------*|-::::::::::::::::::::
:::::::::::::::::::-%:-----%xxxxxxxxxxxxxxxxxxxxx#_|----:*-%:------*|-::::::::::::::::::::
:::::::::::::::::::-%:----%xxxxxxxxxxxxxxxxxxxxxxxx#%---:**|-------*|-::::::::::::::::::::
:::::::::::::::::::-%:---*xxxxxxxxxxxxxxxxxxxxxxxxxxx%--:%*--------*|-::::::::::::::::::::
:::::::::::::::::::-%:--|sxxxxxxxxxxxxxxxxxxxxxxxxxxxx|-:_---------*|-::::::::::::::::::::
:::::::::::::::::::-%:-:#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxs|:&:--------*|-::::::::::::::::::::
:::::::::::::::::::-%:-&xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs*s%--------*|-::::::::::::::::::::
:::::::::::::::::::-%:@xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx&--------*|-::::::::::::::::::::
:::::::::::::::::::-*%xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx&--------*|-::::::::::::::::::::
:::::::::::::::::::-_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx@--------*|-::::::::::::::::::::
:::::::::::::::::::-_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx&--------*|-::::::::::::::::::::
:::::::::::::::::::-_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxs:-------*|-::::::::::::::::::::
:::::::::::::::::::-@xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx_:::::::*|-::::::::::::::::::::
:::::::::::::::::::-|______________________________________%********:-::::::::::::::::::::

'''

def clr():
    subprocess.call("cls", shell=True)

thumbup = emoji.emojize(':thumbs_up:')
noexpr = emoji.emojize(':expressionless:', use_aliases=True)
sleep = emoji.emojize(':sleeping:', use_aliases=True)
confused = emoji.emojize(':confused:', use_aliases=True)
grim = emoji.emojize(':grimacing:', use_aliases=True)
joy = emoji.emojize(':joy:', use_aliases=True)
sp = emoji.emojize(':sparkles:', use_aliases=True)
exc = emoji.emojize(':exclamation:', use_aliases=True)
thumbdown = emoji.emojize(':thumbs_down:', use_aliases=True)
dog = emoji.emojize(':dog:', use_aliases=True)
warn = emoji.emojize(':warning:', use_aliases=True)
no_en = emoji.emojize(':no_entry_sign:', use_aliases=True)
ship = emoji.emojize(':small_red_triangle_down:', use_aliases=True)

def emoji():
    print(thumbup)    
    print(noexpr)
    print(sleep)
    print(confused)
    print(grim)
    print(joy)
    print(sp)
    print(exc)
    print(thumbdown)
    print(dog)
    print(warn)
    print(warn)
    print(no_en)
    print(ship)
    
def Menu():
    try:
        running = True
        while(running):
            print(menu)
            choice = input("Enter your choice: ")
            if(choice == '1'):
                print(p.renderText("Convert GIF to ascii..."))
                subprocess.call("python animation.py", shell=True)
            elif(choice == '2'):
                print(p.renderText('Convert PNGs to ascii...'))
                subprocess.call("python to_ascii.py", shell=True)
            elif(choice == '3'):
                print(p.renderText("View ticket from CLI..."))
                subprocess.call("python ticket_view.py", shell=True)
            elif(choice == '4'):
                print(p.renderText("Displaying FW Scores..."))
                subprocess.call("python pointsGame.py", shell=True)
            elif(choice == '5'):
                print(p.renderText("Today In History..."))
                subprocess.call("python Today_In_History.py", shell=True)
            elif(choice == '6'):
                print(p.renderText("Running a Speed Test..."))
                subprocess.call("python Speed_test.py", shell=True)
            elif(choice == '7'):
                print(p.renderText("Generating Ascii Meme..."))
                subprocess.call("python ascii.py -r rando", shell=True)
            elif(choice == '8'):
                print(p.renderText("Scraping Email..."))
                subprocess.call("python EmailScrape.py", shell=True)
            elif(choice == '9'):
                print(p.renderText("Scraping Tickets..."))
                subprocess.call("python scrape_tickets.py", shell=True)
            elif(choice == 'E'):
                print(p.renderText("EMOJIS..."))
                emoji()
            elif(choice == '0'):
                print(gbye.renderText("See You Space Cowboy.."))
                exit(0)
        else:
            print("Invalid choice, please select a valid choice from 0-9, or E")
    except KeyboardInterrupt:
        print("CLOSING PROGRAM, GOODBYE")

subprocess.call("COLOR f", shell=True)
n = Figlet(font='larry3d')
p = Figlet(font='smslant')
b = Figlet(font='smkeyboard')
gbye = Figlet(font='banner3-D')
try:
    print(logo)
    time.sleep(3)
    subprocess.call("cls", shell=True)

    Menu()
except KeyboardInterrupt:
    Menu()