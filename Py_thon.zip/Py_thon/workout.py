#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 22 13:02:39 2022

@author: SamuelJames
@Give me my workout
"""

# Import openyxl module
import openpyxl
import time
# Import pandas
import pandas as pd
import argparse

#define Parser
parser = argparse.ArgumentParser(description='generate workout by week and part')

def logo():
    logo = '''
                L.I.F.T.
                Look Into File for Training
                _                     _
               | |                   | |
             =H| |====mn=======nm====| |H=
               |_|    ( \\     / )    |_|
                       \\ )(")( /
                       ( /\\_/\\ )
                        \\     /
                         )=O=(
                        /  _  \\
                       /__/ \\__\\
                       | |   | |
                       |_|   |_|
                       (_)   (_)
                       
                            ❚█══█❚
    '''
    print(logo)
    time.sleep(1)

def run_prgrm(inp1, inp2):
    logo()
    # Load the xlsx file
    excel_data = pd.read_excel("Workout_Jan-Feb.xlsx")

    # Print the content
    df_week1 = excel_data[excel_data["Week"] == int(inp1)]

    for row in df_week1.iterrows():
        if str(inp2) in str(row):
            print(row)

#run_prgrm()

parser.add_argument('-w','--workout', nargs=2, help='show me some ascii goodness', required=True)

args = vars(parser.parse_args())

try:
    if args['workout'] != None:
        run_prgrm(args['workout'][0], args['workout'][1])
    else:
        print('Invalid Input: ', args['workout'])
except KeyboardInterrupt:
    print('Program Force CLosed....')