# -*- coding: utf-8 -*-
"""
Created on Wed Feb  9 12:48:43 2022

@author: SamuelJames
@Use: pull a user, cross reference name to get ID, pull all their assets and print them
@changes: I want to add a json post to be able to alter assets from this program
@ Also you can pipe this '|' into a FindSTR for whichever piece you onjly want to see


Example use:
    Python grab_user_json_page.py -n Samuel James
    (Will return invalid as only requesters can be found not agents)
"""
import requests# pip install requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3 # pip install urllib3
from colorama import init # pip install colorama
from termcolor import colored # pip install termcolor
import sys
from pyfiglet import Figlet
import argparse
import emoji

fu = emoji.emojize(':fu:', use_aliases=True)
expr = emoji.emojize(':expressionless:', use_aliases=True)

gbye = Figlet(font='banner3-D')
# use Colorama to make Termcolor work on Windows too
init()

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
#global items array for the input user
items = []
    
def headers(apikey):
    return {'Authorization': 'Bearer {}'.format(apikey),
            'Content-Type': 'application/json'}

api_key = "26suLUhxIvs9IqPG0RFD"
password = "Welcome1"

def what_is_this(d):
    if d == 15000917364:#
         return'LAPTOP'
    elif d == 15000917363:#
        return 'DESKTOP'
    elif d == 15000917351:#
        return 'MONITOR'
    elif d == 15000917342:#
        return 'KEYBOARD AND MOUSE'
    elif d == 15000930680:#
        return 'USB-C DOCK'
    elif d == 15000917359:#
        return 'WEBCAM'
    elif d == 15000940906:#
        return 'HEADSET'
    else:
        return "IDFK"

def ID_From_Name(nm):
    #split = nm.split(" ")
    try:
        fname = nm[0]
        lname = nm[1]
    except IndexError:
        print("Try Again dummy....", expr)
    try:
        for i in range(1,6):
            r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters?per_page=100&page=" 
                             + str(i), auth = (api_key, password), verify=False)
            data = r.json()
            for i in range(100):
                if fname in (data['requesters'][i]['first_name']) and lname in (data['requesters'][i]['last_name']):
                    print("MATCHING ID: ", data['requesters'][i]['id'])
                    User_ID = data['requesters'][i]['id']
                    return User_ID        
    except IndexError:
        print("EOP")

def getUserAssets(ID):
    print("USER ID:", ID)
    try:
        for page in range(1,10):
            url2 = ("https://drivewayfinancecorp.freshservice.com/api/v2/assets?per_page=100&page=" + str(page))
            r3 = requests.get(url2, auth = (api_key, password), verify=False)
            data3 = r3.json()
            #print(data3)
            for i in range(1,100):
                check = (data3['assets'][i]['user_id'])
                if ID == check:
                    ntype = what_is_this(data3['assets'][i]['asset_type_id'])
                    items.append(str(data3['assets'][i]['name']) + " : " + str(ntype))
    except IndexError:
        print("___________________________________________")
        
def grabUser(req_id):
    #if no user ID exists return and continue iterating through tickets
    if(req_id is None):
        print("This isn't a real person, or is an agent", expr)
        sys.exit()

    url = ("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/" + str(req_id)) 
    #Not an agent
    r2 = requests.get(url, auth = (api_key, password), verify=False)

    data2 = r2.json()
    
    #print(data2)
    print(colored("\nUSER INFO: ", 'white', 'on_blue'))
    try:
        for attr in data2['requester']:
            print(attr, ': ', data2['requester'][attr])
            
    except TypeError:
        print(expr)
        print("TYPE-ERROR ENCOUNTERED")

def run_me(inp):
    ID = ID_From_Name(inp)
    grabUser(ID)
    getUserAssets(ID)
    print('USER ASSETS:\n')
    for item in items:
        print(item)
        
parser = argparse.ArgumentParser(description='testing ArgParse')
parser.add_argument('-n','--name', nargs=2, help='The users first and last name separated by a comma with no spaces', required=True)

args = vars(parser.parse_args())


try:
    if args['name'] != None:
        run_me(args['name'])
    else:
        print(fu, fu, fu, fu)
        print('Invalid name: ', args['name'])
except KeyboardInterrupt:
    print(gbye)