# -*- coding: utf-8 -*-
"""
Created on Mon Apr 25 11:14:34 2022

@author: SamuelJames
"""


import fitz

file_path = 'doors.pdf'

def get_text(filepath: str) -> str:
    with fitz.open(filepath) as doc:
        text = ""
        for page in doc:
            text += page.getText().strip()
        return text
test = get_text(file_path)
splitstring = test.split("\n")
for x in splitstring:
    print(x)