# -*- coding: utf-8 -*-
"""
Created on Thu Jun  2 14:17:37 2022

@author: SamuelJames
"""

import subprocess
import time

basic_intf = "netsh interface show interface"
firewall_rules = "netsh advfirewall firewall show rule name=all"
show_int_ips = "netsh interface ip show interfaces"
prev_connected_prof = "netsh wlan show profile"
available = "netsh wlan show networks"
curr_prof_info = "netsh wlan show networks mode=bssid"
disconnect_wifi = "netsh wlan disconnect"
connect = "netsh wlan connect name=\"" #name needs name + "
drivers = "netsh wlan show drivers"
proxys = "netsh winhttp show proxy"

#commands that require admin
capture_packets = "trace start capture=yes tracefile=c:\trace.etl persistent=yes maxsize=4096" #requires admin
stp = "trace stop" #stop a packet trace
fire_off = "netsh advfirewall set currentprofile state off"
fire_on = "netsh advfirewall set currentprofile state on"

subprocess.call(firewall_rules, shell=True)
