# -*- coding: utf-8 -*-
"""
Created on Tue Jan 25 11:50:16 2022

@author: SamuelJames
"""

# Imports______________________________________________________________________
import requests 
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
import time
from colorama import init
from tqdm import tqdm
import ssl

ssl._create_default_https_context = ssl._create_unverified_context
# End Imports__________________________________________________________________

# use Colorama to make Termcolor work on Windows too, initialize with init()
init()

# Variables____________________________________________________________________
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

url='https://lithiamotors.sharepoint.com/sites/IT-InfoSec-Publishing/SitePages/'
r = requests.get(url, stream=True)
print(r)

#with open('C:/Users/SamuelJames/Documents/Inventories/testpdf.pdf', 'wb') as f:
#    f.write(r.content)