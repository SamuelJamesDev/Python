# -*- coding: utf-8 -*-
"""
Created on Tue Apr 26 13:49:20 2022

@author: SamuelJames
"""
import random
#Rock Paper Scissors

choices = ['Rock', 'Paper', 'Scissors']

myWin = 0
myLose = 0
aiWin = 0
aiLose = 0

def AITurn():
    aiChoice = choices[random.randint(0, 2)]
    return aiChoice

def userTurn():
    inp = str(input('Select From the following:\n0-Rock\n1-Paper\n2-Scissors\n'))
    if inp == '0':
        return 'Rock'
    elif inp == '1':
        return 'Paper'
    elif inp == '2':
        return 'Scissors'

def compareChoice(ai, me):
    global aiWin, myWin, aiLose, myLose
    if ai == me:
        print('DRAW!')
        return
    if ai == 'Rock':
        if me == 'Paper':
            myWin += 1
            aiLose += 1
        else:
            myLose += 1
            aiWin += 1
    elif ai == 'Paper':
        if me == 'Scissors':
            myWin += 1
            aiLose += 1
        else:
            myLose += 1
            aiWin += 1
    elif ai == 'Scissors':
        if me == 'Rock':
            myWin += 1
            aiLose += 1
        else:
            myLose += 1
            aiWin += 1

def playTheGame():
    while myWin < 5 and myLose < 5:
        me = userTurn()
        ais = AITurn()
        print('\n\n\nYou have Chosen:\n', me)
        print('AI has chosen:\n', ais)
        compareChoice(ais, me)
        
        print("My Wins:\n", myWin , "\nMy Losses:\n", myLose, "\nAI Wins:\n", aiWin, "\nAI Losses:\n", aiLose)
    if myWin == 5:
        print('You Win!')
    elif myLose == 5:
        print('You Lose!')
        
playTheGame()