# -*- coding: utf-8 -*-
"""
Created on Tue Apr  5 10:26:21 2022

@author: SamuelJames
@Name: R3APSCAN
"""
import pyfiglet
import sys
import socket
from datetime import datetime

vul_ports = [22, 80, 443, 1434, 3389, 8080 ]

ascii_banner = pyfiglet.figlet_format("R3AP3R SCANNER")
print(ascii_banner)
  
def getTarget():
    name = input('Enter taret IP:\n')
     
    # translate hostname to IPv4
    target = socket.gethostbyname(name)
    print('Target Aquired ' + target)
    return target

def quickscan(target):
    time1 = datetime.now()
    # Add Banner
    print("-" * 50)
    print("Scanning Target: " + target)
    print("Scanning started at:" + str(time1))
    print("-" * 50)
    try:
     
        # will scan ports between 1 to 65,535
        for port in vul_ports:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            socket.setdefaulttimeout(1)
         
            # returns an error indicator
            result = s.connect_ex((target,port))
            if result ==0:
                print("Port {} is open".format(port))
            else:
                print('Port {} is LOCKED'.format(port))
            s.close()
        print('TOTAL TIME ELAPSED: ', (time1 - datetime.now()))
    except KeyboardInterrupt:
        print("\n Exiting Program !!!!")
        sys.exit()
    except socket.gaierror:
        print("\n Hostname Could Not Be Resolved !!!!")
        sys.exit()
    except socket.error:
        print("\ Server not responding !!!!")
        sys.exit()
        
def fullscan(target):
    try:
     
        # will scan ports between 1 to 65,535
        for port in range(1,65535):
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            socket.setdefaulttimeout(1)
         
            # returns an error indicator
            result = s.connect_ex((target,port))
            if result ==0:
                print("Port {} is open".format(port))
            s.close()
         
    except KeyboardInterrupt:
        print("\n Exiting Program !!!!")
        sys.exit()
    except socket.gaierror:
        print("\n Hostname Could Not Be Resolved !!!!")
        sys.exit()
    except socket.error:
        print("\ Server not responding !!!!")
        sys.exit()

menu = '''
 __________________________________
|             0-EXIT               |
|             1-QSCAN              |
|             2-FULLSCAN           |
|             3-PORTS              |
|__________________________________|
'''

ports = '''
Port Number	Protocol[s]	Port Service
7	          TCP, UDP	       Echo
19	          TCP, UDP	       Chargen
20	          TCP, FTP        [File Transfer Protocol]
21	          TCP	          FTP Control
22	          TCP	          SSH
23	          TCP	          Telnet
25	          TCP	          SMTP [Simple Mail Transfer Protocol]
37         	TCP, UDP	       Time
53	          UDP	          DNS [Domain Name System]
69	          UDP	          TFTP [Trivial File Transfer Protocol]
79	          TCP, UDP	       Finger
80	          UDP	          HTTP [Hyptertext Transfer Protocol]
110	          TCP	          POP3 [Post Office Protocol v.3]
111         	TCP, UDP	       SUN.RPC [Remote Procedure Calls]
135	          TCP, UDP	       RDC/DCE [Endpoint Mapper] – Microsoft networks
137-139,445	TCP, UDP	       NetBIOS over TCP/IP
161         	TCP, UDP	       SNMP [Simple Network Management Protocol]
443	          TCP	          HTTPS [HTTP over TLS]
512-514	    TCP	          Barkley r-services and r-commands [e.g., rlogin, rsh, rexec]
1433	       TCP, UDP	       Microsoft SQL Server [ms-sql-s]
1434	       TCP, UDP	       Microsoft SQL Monitor [ms-sql-m]
1723	       TCP	          Microsoft PPTP VPN
3389	       TCP	          Windows Terminal Server
8080	       TCP	          HTTP proxy
'''
def menu():
    print(menu)
    choice = input('Choose your option: ')
    if choice == 0:
        exit()
    elif choice == 1:
        target = getTarget()
        quickscan(target)
        menu()
    elif choice == 2:
        target = getTarget()
        fullscan(target)
        menu()
    elif choice == 3:
        print(ports)
        menu()
    else:
        print('INVALID ENTRY.. Please try again..')
        menu()

menu()