# -*- coding: utf-8 -*-
"""
Created on Fri Jan 14 12:20:00 2022

@author: SamuelJames
"""
import random
import math
from samila import Projection
from samila import GenerativeImage
import matplotlib.pyplot as plt

def f1(x,y):
    result = random.uniform(-1,1) * x**2  - math.sin(y**2) + abs(y-x)
    return result

def f2(x,y):
    result = random.uniform(-1,1) * y**12 - math.cos(x**2) + 2*x
    return result

g = GenerativeImage(f1,f2)
g.generate(seed=1456480)
g.plot(projection=Projection.POLAR)
plt.show()