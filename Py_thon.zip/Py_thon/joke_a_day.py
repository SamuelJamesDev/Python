# -*- coding: utf-8 -*-
"""
Created on Sat Mar 26 10:39:52 2022

@author: SamuelJames
"""
import requests
import urllib3
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import pyfiglet
import termcolor
from random import choice
  
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def get_jokes():
    try:
        
        term = input("\nLet me tell you a joke! Give me a topic: ")
  
        response_json = requests.get("https://icanhazdadjoke.com/search",
                                     headers={"Accept": "application/json"}, params={"term": term}, verify=False).json()
  
        results = response_json["results"]
        
        total_jokes = response_json["total_jokes"]
    
        if total_jokes > 1:
            print(f"There are {total_jokes} jokes about {term}. Here's one:\n", choice(
                results)['joke'])
            get_jokes()
        elif total_jokes == 1:
            print(f"I've got one joke about {term}. Here it is:\n", results[0]['joke'])
            get_jokes()
        else:
            print(f"Sorry, I don't have any jokes about {term}! Please try again.\n")
            get_jokes()
    except KeyboardInterrupt:
        print(pyfiglet.figlet_format("\nSEE YOU SPACE COWBOY..."))
        
header = pyfiglet.figlet_format("Find some jokes!")
header = termcolor.colored(header, color="cyan")
print(header)
get_jokes()

#r = requests.get("https://jokes.one/", verify=False)
#print(r.text)