'''
Author: Samuel James
Use: This program will scrape through multiple tickets and return the rows
if a specified string is found within the ticket subject
Date: 12/3/21
Name: find_shit_todo.py
 
'''
import requests 
import json
from bs4 import BeautifulSoup
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
import time
from colorama import init
from termcolor import colored

# use Colorama to make Termcolor work on Windows too
init()

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def foundIt():
    foundit = '''Thats right boys... We got em                         
    '''
    print(colored(foundit, 'cyan'))
    time.sleep(2)
    
def openPrgm():
    logo = '''

              ,,,,.   .,,,.                           .,,,..   ,,,,.
            .,,,,,,,,,,,,,,,.                        ,,,,,,,,,,,,,,,,.
           .,,,*****,*****,,,.                     .,,,*****,,****,,,,
 ,,,,      ,,,*************,,,      ,,,, ,,,       *,,*************,,,,      .,,
 ,,,,,.   ,,,,*************,,,    *,,,,,,,,,,,     ,,,**************,,,    .,,,,
 ,,,,,,,,.,,,,,,,*******,,,,,,,.,,,,,,,,,,,,,,,,. ,,,,,,**********,,,,,..,,,,,,,
 .,,,,,,,,,,,***,,,,,,,,,***,,,,,,,,,,,. ,,,,,,,,,,,,**,,,,,,,,,,,,**,,,,,,,,,,,
  .,,,,,,,,,,,*************,,,,,,,,,,,,  .,,,,,,,,,,,****************,,,,,,,,,,,
    ,,,,,,,,,,,,,******,,,,,,,,,,,,,,      ,,,,,,,,,,,,************,,,,,,,,,,,,
      ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,         ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,.
      (#%#(*,,,,,,,,,,,,,,,,,*/*              .,*,,,,,,,,,,,,,,,,,,,,,,,,,,
     (#&&@@@@@@@&%%%%%%%&@@@@&%#(,            (#%&&%(**,,,,,,,,,,,,**#&&%(/
   ,(%&@@@@@@@@@@@@@@@@@@@@@@@@&#(           (#%&@@@@@@@@@@@@@@@@@@@@@@@&%(/
  .(%&@@@@@@@@@@@@@@@@@@@@@@@@@@&#(.        (#%&@@@@@@@@@@@@@@@@@@@@@@@@@&%(/
  (#&&@@@@@@@@@@@@@@@@@@@@@@@@@@&%#/       *(%&@@@@@@@@@@@@@@@@@@@@@@@@@@@&%(,
 ,(%&@@@@@@@@@@@@@@@@@@@@@@@@@@@@&%(,      (#&@@@@@@@@@@@@@@@@@@@@@@@@@@@@&%#(
 (#&&/,,,,,,,..,*%@@@@@@@@@@@@@@@&%#(     /#%&%*,,,,,,,,,,(@@@@@@@@@@@@@@@@&%(
 (%*,#@@@&,....,.../@@@@@@@@@@@@@@&#(,    (#(,#@@@@(  ...,,,,%@@@@@@@@@@@@@&%(/
 (,.,%@@@(      .,,..&@@@@@@@@@@@@&%(,    (*.*&@@@&,      .,,.(@@@@@@@@@@@@&%#(
 *.,.            .*,,/@@@@@@@@@@@@&%(,    (,..             .**,%@@@@@@@@@@@&%#(
 *,,              ***/@@@@@@@@@@@@&#(,    (,,.             ./**%@@@@@@@@@@@&%#(
 /.,.            ,(/,%@@@@@@@@@@@&&#(     (*,,             *(/*@@@@@@@@@@@@&%(/
 //,**.        ,##(*%@@@@@@@@@@@@&%#/      (*,**         *%#((@@@@@@@@@@@@@&#(
 ,(#/*/((#######(*%@@@@@@@@@@@@@@&#(       (##,*/((###%###/(@@@@@@@@@@@@@@&%(,
  /#%&@&#((((%&@@@@@@@@@@@@@@@@@&%(,       ,(#&@@%#(((#%@@@@@@@@@@@@@@@@@&%#(
   /#%&@@@@@@@@@@@@@@@@@@@@@@@@&%#/         ,(%&@@@@@@@@@@@@@@@@@@@@@@@@&%#(
    (#%&@@@@@@@@@@@@@@@@@@@@@@&%(*           ,(%&@@@@@@@@@@@@@@@@@@@@@@&%#(.
     ,(%&@@@@@@@@@@@@@@@@@@@&&#(*              (#%&@@@@@@@@@@@@@@@@@@@&%#/
       (#%&&@@@@@@@@@@@@@@&&%((                 /(#%&@@@@@@@@@@@@@@@&%#(.
         *(#%&&@@@@@@@@&&%#(/.                    ,(#%&&@@@@@@@@@&&%#(.
           ./(##%%%%%%##(/                           *((##%%%%%##((.
    '''
    print(colored(logo, 'cyan'))
    time.sleep(2)


api_key = "26suLUhxIvs9IqPG0RFD"
password = "Welcome1"
buffspace = '''+++++++++++++++++++++++++++++++++++++++++++++++++'''

ticket_list = []

def getSearchInt():
    inp = input("Enter The # tickets to search through....\n")
    return int(inp)

def getHighestTicket():
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/tickets/", auth = (api_key, password), verify=False)
    print(colored("Retrieving highest ticket number, the response is given below\n", 'white', 'on_cyan') + str(colored(r.status_code, 'white', 'on_green')))
    #soup = BeautifulSoup(r.content, 'html.parser')
    data = r.json()
    #this method allows me to return only the ticket ID, which I can now set to the highest ticket number 
    print(colored("HIGHEST TICKET NUMBER: ", 'white', 'on_cyan'))
    print(data['tickets'][0]['id'])
    top_ticket = data['tickets'][0]['id']
    return top_ticket


def searchTickets(numSrch):
    i = getHighestTicket()
    y = 0
    while y < numSrch:
        r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/tickets/"+str(i), auth = (api_key, password), verify=False)
        #print(colored("Request processed successfully, the response is given below\n", 'white', 'on_blue') + str(colored(r.status_code, 'white', 'on_green')))
        #soup = BeautifulSoup(r.content, 'html.parser')
        data = r.json()
        #print(data)
        status = (data['ticket']['status'])
        i -= 1    
        y += 1
        try:
            #rows = soup.select("div",{"id": "ticket_original_request"})[0].text.strip().replace('\\n', ' ')
            if str(status) == '1' or str(status) == '0':
                print(colored("Matching ticket found: #" + str(i + 1), 'white', 'on_green'))
                print('Status:', status)
                ticket_list.append(str(i + 1))
            else:
                print(colored("No matching status found in ticket #: ",'white','on_magenta'), str(i + 1))
        except IndexError:
            print(colored('Ticket has no status:', 'white', 'on_magenta'))

    if not ticket_list:
        print(buffspace)
        print(colored("No Tickets were found\n", 'grey', 'on_red'))
        print(buffspace)
    else:
        foundIt()
        print(buffspace)
        print(colored("Final ticket List for possible stuff to do\n", 'white', 'on_blue'))
        print(ticket_list)
        print(buffspace)
        time.sleep(3)
        print(colored("Running Ticket_View for each listed ticket...", "blue", "on_white"))
        for t in ticket_list:
            grabTickets(t)

def grabUser(req_id):
            if(req_id is None):
                print('No User exists yet')
                return
            #print(colored('Agent/Requester ID: ', 'blue', 'on_white'))
            #print(req_id)
            try:
                r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/agents/"+str(req_id), auth = (api_key, password), verify=False)
                soupy = BeautifulSoup(r2.content, 'html.parser')
                data2 = r2.json()
                print(data2['agent']['first_name'] + ' ' + data2['agent']['last_name'])    
                
            except ValueError:
                r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/"+str(req_id), auth = (api_key, password), verify=False)
                soupy = BeautifulSoup(r2.content, 'html.parser')
                data2 = r2.json()
                print(colored('Requester Name: ', 'blue', 'on_white'))
                try:
                    print(data2['requester']['first_name'] + ' ' + data2['requester']['last_name'])
                    print(colored('Requester Email: ', 'blue', 'on_white'))
                    print(data2['requester']['primary_email'])
                    print(colored('Requester Job Title: ', 'blue', 'on_white'))
                    print(data2['requester']['job_title'])
                except TypeError:
                    print(data2['requester']['first_name'])
                    print(colored('Requester Email: ', 'blue', 'on_white'))
                    print(data2['requester']['primary_email'])
                    print(colored('Requester Job Title: ', 'blue', 'on_white'))
                    print(data2['requester']['job_title'])
                print(buffspace)

def grabTickets(ticket_num):
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/tickets/"+ticket_num, auth = (api_key, password), verify=False)
    
    if r.status_code == 200:
        print(colored("Request processed successfully, the response is given below\n", 'white', 'on_blue') + str(colored(r.status_code, 'white', 'on_green')))
        soup = BeautifulSoup(r.content, 'html.parser')
        tik = r.json()
        try:
            print("TICKET NUMBER: ", ticket_num)
            test = tik['ticket']['description_text']
            print(test)
            #rows = soup.select("div",{"id": "ticket_original_request"})[0].text.strip().replace('\\n', ' ')
            #print(buffspace + '\n' + rows + '\n')
            data = r.json()
            req_id = data['ticket']['requester_id']
            grabUser(req_id)

        except IndexError:
            print(colored('Ticket has no original request line:', 'white', 'on_red'))
            print('Grabbing ticket info from headers...')
            rows = str(soup.select("h2", {"class": "subject"}))
            if(rows == '[]'):
                print(colored("No Headers", 'grey', 'on_red'))
            else:
                print(buffspace + '\n' + rows + '\n' + buffspace)
    else:
        print("Failed to read ticket.")
        
#Run Program
openPrgm()
try:
    srchNum = getSearchInt()
    searchTickets(srchNum)
except KeyboardInterrupt:
    print('Program Closed...')

