# -*- coding: utf-8 -*-
"""
Created on Fri Apr  1 15:40:00 2022

@author: SamuelJames
"""
#import tkinter as tk
from tkinter import ttk, StringVar, Button
from ttkthemes import ThemedTk
import subprocess

class Widget:
        
    def __init__(self):
        try:
            root = ThemedTk(theme='xpnative')
            root.geometry('300x120')
        
            # Label
            ttk.Label(root, text = "Select a program :", 
                      font = ("Times New Roman", 10)).grid(column = 0, 
                      row = 15, padx = 10, pady = 25)
        
                                             
            #ComboBox
            n = StringVar()
            self.w = ttk.Combobox(root, textvariable=n)
            self.w['values'] = ('animation.py', 'to_ascii.py', 'tree_game.py')
            self.w.grid(column = 1, row = 15)
            self.w.current(0) 
        
            #Button
            button = ttk.Button(root, text="Test", command=self.runp)
            button.grid(row=5, column=0)
        
            root.mainloop()
        except KeyboardInterrupt:
            print('Later HOE')
            
    def runp(self):
        print(self.w.get())
        subprocess.Popen('python '+self.w.get(), shell=True)
         
Widget()