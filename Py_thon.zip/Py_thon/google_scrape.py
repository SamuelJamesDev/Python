# -*- coding: utf-8 -*-
"""
Created on Mon Feb 14 14:04:48 2022

@author: SamuelJames
"""
from bs4 import BeautifulSoup
import requests, json
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

headers = {
    'User-agent':
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.19582"
}

html = requests.get('https://www.google.com/search?q=python', headers=headers, verify=False)
data = html.json()
print(data['page'])
