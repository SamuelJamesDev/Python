# -*- coding: utf-8 -*-
"""
Created on Thu Mar 17 09:01:06 2022

@author: SamuelJames

Trying licenses one more time
"""

import requests # pip install requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning #urllib3
import urllib3 # pip install urllib3
import pandas as pd # pip install pandas
import time # standard package
from datetime import date # Import date class from datetime module
from requests_html import HTMLSession
from bs4 import BeautifulSoup as bs
import concurrent.futures
import requests
import time

out = []
CONNECTIONS = 10
TIMEOUT = 5

tlds = open('../data/sample_1k.txt').read().splitlines()
urls = ['http://{}'.format(x) for x in tlds[1:]]

def load_url(url, timeout):
    ans = requests.head(url, timeout=timeout)
    return ans.status_code

with concurrent.futures.ThreadPoolExecutor(max_workers=CONNECTIONS) as executor:
    future_to_url = (executor.submit(load_url, url, TIMEOUT) for url in urls)
    time1 = time.time()
    for future in concurrent.futures.as_completed(future_to_url):
        try:
            data = future.result()
        except Exception as exc:
            data = str(type(exc))
        finally:
            out.append(data)

            print(str(len(out)),end="\r")

    time2 = time.time()

print(f'Took {time2-time1:.2f} s')

#Removes erronious warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

#_____________________________________________________________________Overview
# Step 1: Pull all managed licenses
# Step 2: Iterate through each user under application -> Users 
# Step 3: Iterate through each user under application -> Installs
# Step 4: Compile all applications and users into one CSV File

# Note: run this program with Python -u to prevent buffering of stdout output
# if you would like to see the total runtime while the program runs

#____________________________________________________________________Variables


api_key = "26suLUhxIvs9IqPG0RFD"
password = "Password"

#grab start time to track total runtime
start_time = time.time()


#_____________________________________________________________License Functions 

def test():
    
    page = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/solutions/categories/15000045710", 
                                   auth = (api_key, 'password'), verify=False)
    data = page.json()
    print(data)

def run_in_full():
    try:
        test()
        #runtime to reduce runtime before finishing program
        print("\n--- %.2f second runtime---" % ((time.time() - start_time)))
    except requests.exceptions.RequestException as e:
        print('\nEncountered Connection Error:\n', e)

#___________________________________________________________Run Program in Full

#try catch for Keyboard Exceptions for gracefully exiting
try:
    run_in_full()
    
#Also cover connections exceptions for graceful restarts
except KeyboardInterrupt:
    print('\nProgram Force Closed...')
    
#________________________________________________________________End of Program