# -*- coding: utf-8 -*-
"""
Created on Thu Mar 24 11:06:08 2022

@author: SamuelJames
"""
import requests 
import json

r = requests.get('http://localhost:9080/rest/api/v1/recordings?startTime=%7BstartTime=0&endTime=1597760950502')

print(r.status_code)