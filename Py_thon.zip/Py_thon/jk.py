# -*- coding: utf-8 -*-
"""
Created on Mon Mar 28 07:34:34 2022

@author: SamuelJames
"""

import requests
import urllib3
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import pyfiglet
import json

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def get_jokes():
    try:
        r = requests.get("https://www.ajokeaday.com/", verify=False)
        data = json.loads(r.text)
        print(data)
        
    except KeyboardInterrupt:
        print(pyfiglet.figlet_format("\nSEE YOU SPACE COWBOY..."))

get_jokes()