import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from bs4 import BeautifulSoup
import urllib3
from colorama import init
from termcolor import colored

# use Colorama to make Termcolor work on Windows too
init()

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

r = requests.get('https://www.history.com/this-day-in-history', verify=False)

#r.encoding = 'utf-8'
#print(r.text)
if r.status_code == 200:
  print("Request processed successfully, the response is given below\n_____________________________________\n", colored(r, 'white', 'on_green'), '\n' )
  soup = BeautifulSoup(r.content, 'html.parser')
  rows = soup.select('h1.m-detail-header--title')[0].text.strip()
  print(colored('Today In History: ', 'white', 'on_blue'))
  print(rows)
  
else:
  print(colored('Page ERROR, CANNOT READ PAGE', 'white', 'on_red'))
  print(colored(r, 'red', 'on_white'))
  
  