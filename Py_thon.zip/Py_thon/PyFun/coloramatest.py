# -*- coding: utf-8 -*-
"""
Created on Thu Dec  2 08:33:07 2021

@author: SamuelJames
"""
# Testing Colorama uses
from colorama import Fore, Back, Style
print(Fore.BLUE + 'some blue text')
print(Back.GREEN + 'and with a green background')
print(Style.DIM + 'and in dim text')
print(Style.RESET_ALL)
print('back to normal now')