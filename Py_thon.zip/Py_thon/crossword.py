# -*- coding: utf-8 -*-
"""
Created on Wed May 11 15:11:13 2022

@author: SamuelJames
Work has dragged today. This is a dumbass crossword game for Windows CLI
"""

words = ['Era', 'Area', 'Ere', 'One', 'Eli', 'Ore', 'Ale', 'Ate', 'Erie', 'Ali']

hints = ['a distinct period of history with a unique characteristic.', 
         'a region or part of the world; the extent or measurement of a surface.', 
         'an old English word meaning “before.”',
         'half of two; a specific person or thing.',
         'a Hebrew name meaning “High” or “elevated.”',
         'a naturally occurring solid material from which a mineral can be extracted.',
         'a type of beer which has a high alcoholic content and bitter flavor.',
         'having consumed food.',
         'a member of the Native American community living south of the lake with the same name, Lake Erie.',
         'an Arabic name meaning “High” or “elevated.”'
         ]


