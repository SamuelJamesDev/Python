#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 17 12:34:58 2022

@author: SamuelJames
"""

# Program to make a simple
# login screen 
 
import requests 
import json
from bs4 import BeautifulSoup
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
import time
from termcolor import colored
import emoji
from io import StringIO
from html.parser import HTMLParser
from tqdm import tqdm 
import tkinter as tk
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Variables____________________________________________________________________
#API key works, password does not matter
api_key = "26suLUhxIvs9IqPG0RFD"
password = "Biggie556!" 
#this can be any made up password, it doesn't actually check

class MLStripper(HTMLParser):
    def __init__(self):
        super().__init__()
        self.reset()
        self.strict = False
        self.convert_charrefs= True
        self.text = StringIO()
    def handle_data(self, d):
        self.text.write(d)
    def get_data(self):
        return self.text.getvalue()

def strip_tags(html):
    s = MLStripper()
    s.feed(html)
    return s.get_data()

def grabTicket(ticket_num):
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/tickets/"+ticket_num, auth = (api_key, password), verify=False)
    if r.status_code == 200:
        print(colored("Request processed successfully, the response is given below\n", 'white', 'on_blue') + str(colored(r.status_code, 'white', 'on_green')))
        try:
            data = r.json()
            #print(data)
            #this method allows me to return only the ticket ID, which I can now set to the highest ticket number 
            req_id = data['ticket']['requester_id']
            print("REQUEST ID: ", req_id)
            r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/"+str(req_id), auth = (api_key, password), verify=False)
           
            data2 = r2.json()
            #print(data2)
            rows = data['ticket']['description']
            print("TICKET BODY: \n", strip_tags(rows))
            text1 = strip_tags(rows)
            try:
                print('\n')
                print("NAME: ", data2['requester']['first_name'] + ' ' + data2['requester']['last_name'])
                print("EMAIL: ", data2['requester']['primary_email'])
                text2 = ("NAME: ", data2['requester']['first_name'] + ' ' + data2['requester']['last_name']) 
                text3 = ("EMAIL: ", data2['requester']['primary_email'])
            except TypeError:
                print("WELL SHIT THEY DON'T EXIST...")
        except IndexError:
            print(colored('Ticket has no original request line:', 'white', 'on_red'))
            print(rows)
    else:
        print("Failed to read ticket.")
        time.sleep(.5)
    return 'Ticket Number: ' + str(ticket_num) + '\n' + str(text1) + '\n' + str(text2) + '\n' + str(text3)
    

root=tk.Tk()
 
# setting the windows size
root.geometry("900x600")
  
# declaring string variable
# for storing name and password
name_var=tk.StringVar()
text_var=tk.StringVar()
 
  
# defining a function that will
# get the name and password and
# print them on the screen
def submit():
 
    name=name_var.get()
    print("The ticket number is: " + name)
    test = grabTicket(name)
    name_var.set("")
    text_var.set(test)
    output_label["text"]=test
     
# creating a label for Ticket Number
name_label = tk.Label(root, text = 'Ticket Number', font=('calibre',10, 'bold'))

# creating a label for Ticket Number
text_label = tk.Label(root, text = 'Ticket Info:', font=('calibre',10, 'normal'))

# creating a label for Ticket Number
output_label = tk.Label(root, text = 'SHOULD APPEAR HERE', font=('calibre',10,'normal'))
  
# creating a entry for input
name_entry = tk.Entry(root, textvariable = name_var, font=('calibre',10,'normal'))
  
# creating a button using the widget
# Button that will call the submit function
sub_btn=tk.Button(root,text = 'Submit', command = submit)
  
# placing the label and entry in
# the required position using grid
# method
name_label.grid(row=0,column=0)
name_entry.grid(row=0,column=1)
text_label.grid(row=4,column=0)
output_label.grid(row=5,column=0)
sub_btn.grid(row=2,column=1)
  
# performing an infinite loop
# for the window to display
try:
    root.mainloop()
except KeyboardInterrupt:
    print('Later Dude..')