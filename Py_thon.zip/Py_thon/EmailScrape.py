# -*- coding: utf-8 -*-
"""
Created on Tue Nov 30 09:14:34 2021

@author: SamuelJames
"""

"""Script to fetch emails with matching string in title and subject from outlook."""

import time
import win32com.client
from datetime import datetime, timedelta
from tqdm import tqdm

def loadBar(m):
    for i in tqdm (range(len(m)), 
               desc="searching email...", 
               ascii=False, ncols=75):
        time.sleep(.1)
        

def extract(regexStr):
    """Get emails from outlook."""
    items = []
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    inbox = outlook.GetDefaultFolder(6).Folders["No-Answer"]  # "6" refers to the inbox
    messages = inbox.Items
    loadBar(messages)
    i = 0
    for msg in list(messages):
        i += 1
        if(regexStr in msg.Body):
            contInp(msg, i)

def contInp(msg, i):
    text = input("Press enter to continue...\n")
    if text == "":
        print('___________________________________________________________________')
        print('EMAIL #: ', i)
        print('Sent On: ',msg.senton)
        print('Sender: ',msg.Sender)
        #print('Subject: ',msg.Subject)
        print(msg)
        print('___________________________________________________________________')
    
    elif text == "exit":
        print('LATER HOE')
        exit()
    else:
        print("you typed text before pressing enter, please try again")
        contInp()

def openPrgm():
    logo = '''
    B.O.O.K.S.
    Big Ocean Of Knowledge Search
       .--.                   .---.
   .---|__|           .-.     |~~~|
.--|===|--|_          |_|     |~~~|--.
|  |===|  |'\     .---!~|  .--|   |--|
|%%|   |  |.'\    |===| |--|%%|   |  |
|%%|   |  |\.'\   |   | |__|  |   |  |
|  |   |  | \  \  |===| |==|  |   |  |
|  |   |__|  \.'\ |   |_|__|  |~~~|__|
|  |===|--|   \.'\|===|~|--|%%|~~~|--|
^--^---'--^    `-'`---^-^--^--^---'--'
    '''
    print(logo)
    time.sleep(0.5)

openPrgm()

inp = input("Enter String to Search In Emails...\n")
extract(inp)