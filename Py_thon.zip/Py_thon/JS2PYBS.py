# -*- coding: utf-8 -*-
"""
Created on Thu May  5 13:41:15 2022

@author: SamuelJames

this mf turns this bs from python to javascript then prints that shit
"""

import json

def openIt(filename):
    translate = []
    with open(filename) as file:
        lines = file.readlines()
        lines = [line.rstrip() for line in lines]
        for line in lines:
            print(line)
            translate.append(line)
    return translate

def convert(line):
#    line = dict(line)
    y = json.dumps(line)
    return y

test = openIt('hello_world.py')

for line in test:
    x = convert(line)
    print(x)

