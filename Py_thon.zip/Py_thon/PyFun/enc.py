# -*- coding: utf-8 -*-
"""
Created on Fri Nov 19 15:16:14 2021

@author: SamuelJames
"""
# import required module
from cryptography.fernet import Fernet
# key generation
key = Fernet.generate_key()
  
# string the key in a file
with open('filekey.key', 'wb') as filekey:
   filekey.write(key)