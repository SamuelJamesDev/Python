# -*- coding: utf-8 -*-
"""
Created on Tue Jan 25 10:52:02 2022

@author: SamuelJames
"""


'''
All Function calls in numpy_financial:
    
fv(rate, nper, pmt, pv[, when]) - Compute the future value.

ipmt(rate, per, nper, pv[, fv, when]) - Compute the interest portion of a payment.

irr(values) - Return the Internal Rate of Return (IRR).

mirr(values, finance_rate, reinvest_rate) - Modified internal rate of return.

nper(rate, pmt, pv[, fv, when]) - Compute the number of periodic payments.

npv(rate, values) Returns the NPV (Net Present Value) - of a cash flow series.

pmt(rate, nper, pv[, fv, when]) - Compute the payment against loan principal plus interest.

ppmt(rate, per, nper, pv[, fv, when]) - Compute the payment against loan principal.

pv(rate, nper, pmt[, fv, when]) - Compute the present value.

rate(nper, pmt, pv, fv[, when, guess, tol, …]) - Compute the rate of interest per period.
'''

# USE EXAMPLE #
#What is the monthly payment needed to pay off a $200,000 loan in 15 years at an annual interest rate of 7.5%?
#>>> npf.pmt(0.075/12, 12*15, 200000)
#-1854.0247200054619

#this is the necessary import, all subfunctions should be present
import numpy_financial as npf
import numpy as np

def fval():
    rate = int(input('Enter the given rate: \n'))
    nper = int(input('Enter the number of payments: \n'))
    pmt = int(input('Enter the payment value: \n')) #will be negative to reflect removal of payment
    pvcalc = int(input('Enter the present value: \n')) #will be negative to reflect removal of payment

    test = npf.fv(rate, nper, pmt, pvcalc)
    print("np.fv == :\n", test)

def countPayments():
    interest_rate=0.04/12
    payment_per_month=-400
    loan_amount=20000
    npf.nper(0.04/12, -400, 20000)
#    array(54.78757726)
    n_payments = npf.nper(interest_rate, payment_per_month, loan_amount)
    print(n_payments)
    
def fndPayInterest():
    interest_rate=0.04/12
    periods = np.arange(30*12) + 1
    mortgage_amount = -500
    interest_per_month = npf.ipmt(interest_rate, periods, 30*12, mortgage_amount)
    for i in range(len(interest_per_month)):
        print("\nMonth: ", i)
        print("Interest: ", interest_per_month[i])
    
#fval()
#countPayments()
#fndPayInterest()