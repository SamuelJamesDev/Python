# -*- coding: utf-8 -*-
"""
Created on Wed Jan  5 11:11:21 2022

@author: SamuelJames
"""

import requests 
import json
from bs4 import BeautifulSoup
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
import time

# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Variables
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

''' 
15000380921 = Systems
15000380551 = Defi System
15000335944 = DFC IT Support
15000380549 = NLS Requests
15000746557 = Payix Issues
15000745145 = Phone System
'''

menu1 = ''' 
Please select from the following groups:
1 = Systems
2 = Defi System
3 = DFC IT Support
4 = NLS Requests
5 = Payix Issues
6 = Phone System
'''

menu2 = ''' 
Please select from the following priorities:
1 = Low
2 = Medium
3 = High
'''

#API key works, password does not matter
api_key = "26suLUhxIvs9IqPG0RFD"
password = "Biggie556!" 
#this can be any made up password, it doesn't actually check

headers = { 'Content-Type' : 'application/json' }

ticket = {
    'subject' : 'Create Program to auto-submit tickets',
    'description' : 'Create Program that can auto-submit a ticket given specific parameters',
    'email' : 'SamuelJames@lithia.com',
    'group_id' : 15000335944,
    'priority' : 1,
    'status' : 2,
    'cc_emails' : ['samueljames@drivewayfinancecorp.com']
}

# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Functions


# ++++++++++++++++++++++++++++++++++++++++++++++++++++ Request & Create Ticket
r = requests.post("https://drivewayfinancecorp.freshservice.com/api/v2/tickets", 
                  auth = (api_key, password), headers = headers, data = json.dumps(ticket))
#data2 = r.json()
#print(data2)

if r.status_code == 201:
  print("Ticket created successfully, the response is given below" + str(r.status_code))
  print("Location Header : " + r.headers['Location'])
else:
  print("Failed to create ticket, errors are displayed below,\n") 
  response = json.loads(r.content)
  print(response["errors"]) 

  print("x-request-id : " + r.headers['x-request-id'])
  print("Status Code : " + str(r.status_code))
