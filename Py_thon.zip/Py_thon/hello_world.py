# -*- coding: utf-8 -*-
"""
Created on Thu May  5 13:52:52 2022

@author: SamuelJames
"""

print('Hello World')