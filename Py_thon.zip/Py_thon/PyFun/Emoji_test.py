# -*- coding: utf-8 -*-
"""
Created on Wed Nov 17 11:37:57 2021

@author: SamuelJames
Use: This program is a simple py_emoji test to print all emojis 
Date: 11/16/21
Name: Emoji_test.py

"""

import emoji
import time

thumbup = emoji.emojize(':thumbs_up:')
noexpr = emoji.emojize(':expressionless:', use_aliases=True)
sleep = emoji.emojize(':sleeping:', use_aliases=True)
confused = emoji.emojize(':confused:', use_aliases=True)
grim = emoji.emojize(':grimacing:', use_aliases=True)
joy = emoji.emojize(':joy:', use_aliases=True)
sp = emoji.emojize(':sparkles:', use_aliases=True)
exc = emoji.emojize(':exclamation:', use_aliases=True)
thumbdown = emoji.emojize(':thumbs_down:', use_aliases=True)
dog = emoji.emojize(':dog:', use_aliases=True)
warn = emoji.emojize(':warning:', use_aliases=True)
no_en = emoji.emojize(':no_entry_sign:', use_aliases=True)
ship = emoji.emojize(':small_red_triangle_down:', use_aliases=True)

def slp():
    time.sleep(1)

def printEmojis():    
    print(thumbup)
    slp()
    print(noexpr)
    slp()
    print(sleep)
    slp()
    print(confused)
    slp()
    print(grim)
    slp()
    print(joy)
    slp()
    print(sp)
    slp()
    print(exc)
    slp()
    print(thumbdown)
    slp()
    print(dog)
    slp()
    print(warn)
    slp()
    print(no_en)
    slp()
    print(ship)
    slp()
    
    print("Complete...")
printEmojis()