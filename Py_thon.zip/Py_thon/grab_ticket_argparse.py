# -*- coding: utf-8 -*-
#!/usr/bin/env python
"""
Created on Wed Feb 16 09:12:52 2022

@author: SamuelJames
"""

import argparse
import requests 
import json
from bs4 import BeautifulSoup
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
import time
from termcolor import colored
import emoji
from io import StringIO
from html.parser import HTMLParser
from tqdm import tqdm

grim = emoji.emojize(':grimacing:', use_aliases=True)
thumbup = emoji.emojize(':gift:', use_aliases=True)
fu = emoji.emojize(':fu:', use_aliases=True)

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Variables____________________________________________________________________
#API key works, password does not matter
api_key = "26suLUhxIvs9IqPG0RFD"
password = "Biggie556!" 
#this can be any made up password, it doesn't actually check

buffspace = '''____________________________________________________'''

def loadbar():
    for i in tqdm (range(100), 
               desc="Loading…", 
               ascii=False, ncols=75):
        time.sleep(0.05)

class MLStripper(HTMLParser):
    def __init__(self):
        super().__init__()
        self.reset()
        self.strict = False
        self.convert_charrefs= True
        self.text = StringIO()
    def handle_data(self, d):
        self.text.write(d)
    def get_data(self):
        return self.text.getvalue()

def strip_tags(html):
    s = MLStripper()
    s.feed(html)
    return s.get_data()

def grabTicket(ticket_num):
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/tickets/"+ticket_num, auth = (api_key, password), verify=False)
    if r.status_code == 200:
        print(colored("Request processed successfully, the response is given below\n", 'white', 'on_blue') + str(colored(r.status_code, 'white', 'on_green')))
        try:
            data = r.json()
            #print(data)
            #this method allows me to return only the ticket ID, which I can now set to the highest ticket number 
            req_id = data['ticket']['requester_id']
            print("REQUEST ID: ", req_id)
            r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/"+str(req_id), auth = (api_key, password), verify=False)
           
            data2 = r2.json()
            #print(data2)
            rows = data['ticket']['description']
            print("TICKET BODY: \n", strip_tags(rows))
            try:
                for i in range(10):
                    print(thumbup, end='')
                    time.sleep(1)
                print('\n')
                print("NAME: ", data2['requester']['first_name'] + ' ' + data2['requester']['last_name'])
                print("EMAIL: ", data2['requester']['primary_email'])
            except TypeError:
                print("WELL SHIT THEY DON'T EXIST...")
        except IndexError:
            print(colored('Ticket has no original request line:', 'white', 'on_red'))
            for i in range(5):
                print(grim, end='')
                time.sleep(.5)
            print(buffspace + '\n' + rows + '\n' + buffspace)
    else:
        print("Failed to read ticket.")
        print(grim, end='')
        time.sleep(.5)

parser = argparse.ArgumentParser(description='testing ArgParse')
parser.add_argument('-t','--ticket_num', help='The ticket to check', required=True)

args = vars(parser.parse_args())
try:
    if len(args['ticket_num']) > 3:
        loadbar()
        grabTicket(args['ticket_num'])
    else:
        print(fu, fu, fu, fu)
        print('Invalid ticket number: ', args['ticket_num'])
except KeyboardInterrupt:
    print('SEE YOU LATER SPACE COWBOY...')
