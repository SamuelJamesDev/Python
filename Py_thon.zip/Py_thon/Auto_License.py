# -*- coding: utf-8 -*-
"""
Created on Fri Mar  4 07:59:42 2022
Author: Samuel James
Use: This program will scrape through software and produce a 
list of users under each software application in FreshWorks
Filename: Auto_Licensces.py
"""

import requests # pip install requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning #urllib3
import urllib3 # pip install urllib3
import pandas as pd # pip install pandas
import time # standard package
from datetime import date # Import date class from datetime module
import json

#Removes erronious warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

#_____________________________________________________________________Overview
# Step 1: Create a session object to persist certain parameters across all requests
# Step 1: Pull all managed licenses
# Step 2: Iterate through each user under application -> Users 
# Step 3: Iterate through each user under application -> Installs
# Step 4: Compile all applications and users into one CSV File

# Note: run this program with Python -u to prevent buffering of stdout output
# if you would like to see the total runtime while the program runs

#____________________________________________________________________Variables

#required for any request out to FreshWorks
api_key = "26suLUhxIvs9IqPG0RFD"
password = "Password"

#grab start time to track total runtime
start_time = time.time()

# Various variables for iteration
page_stop = 8
sleep_time = 5
user_stop = 100
license_stop = 17
good = 200
minute = 60

#gather IDS
ids = []

# 2 requests to manage the number of requests allowed to FreshWorks within a given timespan
s = requests.Session()
s2 = requests.Session()

#2d list to contain license name and users under the corresponding license.
names = [[]]

#________________________________________________________________User Functions

# Function to catch any prevented requests and switch to session s2 if
# the max requests have been made

def make_request(url):
    # create a request from the session object
    req = s.get(url, auth = (api_key, password), verify=False)
    # close the session request to reduce the number of requests made at once
    s.close()
    # if the request returns <200> pull the json() info else do another request
    if req.status_code == good:
        data = req.json()
        return data
    else:
        print('FAILED STATUS CODE: ', req.status_code)
        req = s2.get(url, auth = (api_key, password), verify=False)
        s2.close()
    
    data = req.json()
    return data
        
    
# retrieve users by user ID regardless of whether the user an agent or requester
# I call the session directly here to prevent JSON Decoder errors
def grabUser(req_id, num):
            if(req_id is None):
                return
            # try grabbing from agents, except value error and search requesters
            try:
                # parse to JSON
                agent = s.get("https://drivewayfinancecorp.freshservice.com/api/v2/agents/"+str(req_id), auth = (api_key, password), verify=False)
                user_data1 = agent.json()
                # grab the name from JSON 
                name = (user_data1['agent']['first_name'] + ' ' + user_data1['agent']['last_name'])
                # add to our list of users if not present already
                if name not in names[num]:
                    names[num].append(name)

            except ValueError:
                try:
                    requester = s.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/"+str(req_id), auth = (api_key, password), verify=False)
                    user_data2 = requester.json()
                    # grab the name from JSON add to our list of users if not present already
                    name = (user_data2['requester']['first_name'] + ' ' + 
                            user_data2['requester']['last_name'])
                    if name not in names[num]:
                        names[num].append(name)
                    
                # Not an Agent and has only one name i.e. looker or noreply
                except TypeError:
                    requester = s.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/"+str(req_id), auth = (api_key, password), verify=False)
                    user_data2 = requester.json()
                    # grab the 1st name from JSON add to our list of users if not present already
                    name = (user_data2['requester']['first_name'])
                    if name not in names[num]:
                        names[num].append(name)
                except Exception as e:
                    print(e)

def grabLicenseUsers(id_in, num):
    # Print name of license to console
    print('Grabbing users page for: ', names[num][0])
    #The largest volume of users to a license should only take up ~8 pages
    for c in range(1, page_stop):
        try:
            #use ID to pull users from license "Users" page
            rdata = make_request("https://drivewayfinancecorp.freshservice.com/api/v2/applications/" 
                                 + str(id_in) + "/users?page=" + str(c) + '&per_page=100')
            for jk in range(1, user_stop):
                grabUser(rdata['application_users'][jk]['user_id'], num)
        #When we have reached the end of users 
        except IndexError:
            pass
            
def grabInstallUsers(id_in, num):
    # Print name of license to console
    print('Grabbing Installs page for: ', names[num][0])
    #The largest volume of users to a license should only take up ~8 pages
    for c in range(1, page_stop):
        try:
            #use ID to pull users from license "Installs" page
            rdata2 = make_request("https://drivewayfinancecorp.freshservice.com/api/v2/applications/" 
                                  + str(id_in) + "/installations?page=" + str(c) + '&per_page=100')
            for lk in range(1, user_stop):
                grabUser(rdata2['installations'][lk]['user_id'], num)   
        #When we have reached the end of isntalls 
        except IndexError:
            pass
#_____________________________________________________________Software Functions 
    
def intoSoftware(ids):
    print('ID LENGTH:' , len(ids))
    try:
        for g in range(len(ids)):
            #Check the user page
            grabLicenseUsers(ids[g], g)
            grabInstallUsers(ids[g], g)
    # if we hit an Index Exception we have iterated all pages
    except IndexError:
        print("All License Users have now been pulled")
        
def grabSoftware(j):
        #grab all applications
        data = make_request("https://drivewayfinancecorp.freshservice.com/api/v2/applications?per_page=100&page=" 
                     + j)
        try:
            #loop through each application that is managed and pull the name and ID
            for i in range(0, user_stop):     
                # Only pull managed application information
                if(data['applications'][i]['status'] != 'managed'):
                    pass
                else:
                    row = []
                    row.append(data['applications'][i]['name'].upper())
                    names.append(row)
                    ids.append(data['applications'][i]['id'])

        except IndexError:
            pass

#_______________________________________________________CSV & Program Functions

def reset():
    # We have to clear both lists before a restart of the program runs to ensure
    # the number of software ids are accurate
    ids.clear()
    names.clear()

def create_app_user_list(arr):
    # Use date to distinguish filenames
    today = date.today()
    filePath = 'Licenses' + '_' + (str(today)) + '.csv'
    # Create a transposed list to make columns not rows
    # This is also where I remove any entries with < 2 users
    df = pd.DataFrame([x for x in arr if x != None and len(x) > 2]).T
    # Make the csv, remove numbered header and index
    df.to_csv(filePath, index=False, header = False)
    

def run_in_full():
    try:
        # for the range of licenses
        for j in range(1, license_stop):
            try:
                # grab each index of license
                grabSoftware(str(j))
                # except when we have hit the end of the index
            except IndexError:
                print("\nSoftware List Complete...")
        # remove the empty initial space
        names.remove(names[0])
        # Add users to list of applications
        intoSoftware(ids)
         #make a csv of the users to software applications
        create_app_user_list(names)
        
        #runtime to reduce runtime before finishing program
        print("\n--- %.2f minute runtime---" % ((time.time() - start_time) / minute))
        
    #if we hit a connection error, recursively re-try the function
    except requests.exceptions.RequestException as e:
        #following a failure in connection allow infinite retries
        print('\nEncountered Connection Error:\n', e)
        print('\nforcing re-run...') 
        # Sleep for 5 seconds to allow requests enough time for the new request
        time.sleep(sleep_time)
        reset()
        run_in_full()

#___________________________________________________________Run Program in Full

#try catch for Keyboard Exceptions for gracefully exiting
try:
    run_in_full()
    
#Also cover connections exceptions for graceful restarts
except KeyboardInterrupt:
    print('\nProgram Force Closed...')
    
#________________________________________________________________End of Program