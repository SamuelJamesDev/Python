# -*- coding: utf-8 -*-
"""
Created on Thu Apr 21 12:20:36 2022

@author: SamuelJames
"""
'''
import LOADING_STUFF

test = LOADING_STUFF.weapon

LOADING_STUFF.getLoadNames()
try:
    LOADING_STUFF.LoadingDemo()
    
except KeyboardInterrupt:
    print('')


'''

import sys
from scapy.all import *
from art import *

IFACE_NAME1 = "Realtek USB GbE Family Controller #2"
IFACE_NAME2 = "Microsoft Wi-Fi Direct Virtual Adapter"
IFACE_NAME3 = "Microsoft Wi-Fi Direct Virtual Adapter #2"
IFACE_NAME4 = "Intel(R) Wi-Fi 6 AX201 160MHz"
IFACE_NAME5 = "8DF7BFEE-0A5E-41AC-9DDA-32F64ECDB60C}"
IFACE_NAME6 = "0B634D7D-EF55-484E-9E7D-41C845F7AC13"


devices = set()

def testing():
    request = ARP() 
    
    request.pdst = '10.28.54.1/24'
    broadcast = Ether() 
        
    broadcast.dst = 'ff:ff:ff:ff:ff:ff'
        
    request_broadcast = broadcast / request 
    clients = srp(request_broadcast, timeout = 10,verbose = 1)[0] 
    for element in clients: 
        print(element[1].psrc + "      " + element[1].hwsrc) 


def getMacs(target):
    ans, unans = sr(IP(dst=target, ttl=(4,25),id=RandShort())/TCP(flags=0x2))
    print(ans, '\n', unans)
    
def PacketHandler(pkt):
    #print(pkt.show())
    if pkt.haslayer(Dot11):
        print("[*] Dot11 IFace discovered")
        dot11_layer = pkt.getlayer(Dot11)
          
        if dot11_layer.addr2 and (dot11_layer.addr2 not in devices):
            devices.add(dot11_layer.addr2)
            print(dot11_layer.addr2)
  
#print(get_if_list())
#sniff(iface=IFACE_NAME4, count=50, prn=PacketHandler)
#testing()
getMacs("10.28.54.1/24")
