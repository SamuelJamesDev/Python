# -*- coding: utf-8 -*-
"""
Created on Sat Jan 15 15:33:12 2022

@author: SamuelJames
"""
# Imports______________________________________________________________________
import requests 
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
import time
from colorama import init
from tqdm import tqdm

# End Imports__________________________________________________________________

# use Colorama to make Termcolor work on Windows too, initialize with init()
init()

# Variables____________________________________________________________________
#API key works, password does not matter
api_key = "26suLUhxIvs9IqPG0RFD"
password = "Biggie556!" 

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

active = []
active2 = []
user = []
i = 0

def openPrgm():
    logo = '''
    C.A.C.T.U.S.
    Check All Current Team User Statuses
           *-*,
       ,*\/|`| \

        \'  | |'| *,
        \ `| | |/ )
         | |'| , /
         |'| |, /
       __|_|_|_|__
      [___________]
       |         |
       |         |
       |         |
       |_________|
    '''
    print(logo)
    
def loadbar():
    for i in tqdm (range (6), 
               desc="Compiling Users...", 
               ascii=False, ncols=75):
                if i != 0:
                    grabUser(i)
    activeOnly(user)
    #print(user)

def activeOnly(users):
    for i in range(len(users)):
        if "True" in users[i]:
            active.append(users[i])
    
    for j in range(len(active)):
        print(active[j])
        contInp()
        
def contInp():
    text = input("Press enter to continue...\n")
    if text == "":
        print("_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_")
    else:
        print("you typed text before pressing enter, please try again")
        return

def grabUser(page):
            try:
                r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/?per_page=100&page="
                                  + str(page), auth = (api_key, password), verify=False)
                data2 = r2.json()
                #print(data2)
                for i in range(len(data2['requesters'])):
                    user.append(str(data2['requesters'][i]['first_name']) + 
                                " " + str(data2['requesters'][i]['last_name']) + 
                                " " + str(data2['requesters'][i]['active']))
            except ValueError:
                r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/"
                                  , auth = (api_key, password), verify=False)
                data2 = r2.json()
                print(data2)
try: 
    openPrgm()
    loadbar()
except KeyboardInterrupt:
    print("GOODBYE..")