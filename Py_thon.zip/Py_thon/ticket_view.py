'''
Author: Samuel James
Use: This program will scrape a single ticket subject given the number
Date: 12/3/21
Name: ticket_view.py
 
'''

import requests 
import json
from bs4 import BeautifulSoup
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
import time
from colorama import init
from termcolor import colored
import re
from tqdm import tqdm
import emoji


grim = emoji.emojize(':grimacing:', use_aliases=True)
thumbup = emoji.emojize(':thumbs_up:')
# use Colorama to make Termcolor work on Windows too, initialize with init()
init()

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Variables____________________________________________________________________
#API key works, password does not matter
api_key = "26suLUhxIvs9IqPG0RFD"
password = "Biggie556!" 
#this can be any made up password, it doesn't actually check

buffspace = '''____________________________________________________'''

# Functions____________________________________________________________________
def loadbar():
    for i in tqdm (range (101), 
               desc="Loading…", 
               ascii=False, ncols=75):
        time.sleep(0.05)

def openPrgm():
    logo = '''
    TICKET IN TRANSIT SYSTEM 
    MMMMMMMMMMMMMMMMMMMMMMMMMMM
    MBM---------------------M M
    MMM---------------------MMM
    MMM---------------------MMM
    MMM---------------------MMM
    MMM---------------------MMM
    MMM---------------------MMM
    MMMMMMMMMMMMMMMMMMMMMMMMMMM
    MMMMM++++++++++++++++MMMMMM
    MMMMM++MMMMM+++++++++MMMMMM
    MMMMM++MMMMM+++++++++MMMMMM
    MMMMM++MMMMM+++++++++MMMMMM
    MMMMM++++++++++++++++MMMMMM
    '''
    print(logo)
    

def grabTicket(ticket_num):
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/tickets/"+ticket_num, auth = (api_key, password), verify=False)
    if r.status_code == 200:
        print(colored("Request processed successfully, the response is given below\n", 'white', 'on_blue') + str(colored(r.status_code, 'white', 'on_green')))
        soup = BeautifulSoup(r.content, 'html.parser')
        try:
            loadbar()
            data = r.json()
            print(data)
            #this method allows me to return only the ticket ID, which I can now set to the highest ticket number 
            req_id = data['ticket']['requester_id']
            print("REQUEST ID: ", req_id)
            r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/"+str(req_id), auth = (api_key, password), verify=False)
           
            soupy = BeautifulSoup(r2.content, 'html.parser')
            data2 = r2.json()
            #print(data2)
            rows = soup.select("div",{"id": "ticket_original_request"})[0].text.strip().replace('\\n', ' ')
            print("TICKET BODY: \n", rows)
            try:
                for i in range(10):
                    print(thumbup, end='')
                    time.sleep(.5)
                print('\n')
                print("NAME: ", data2['requester']['first_name'] + ' ' + data2['requester']['last_name'])
                print("EMAIL: ", data2['requester']['primary_email'])
            except TypeError:
                print("WELL SHIT THEY DON'T EXIST...")
        except IndexError:
            print(colored('Ticket has no original request line:', 'white', 'on_red'))
            for i in range(10):
                print(grim, end='')
                time.sleep(.5)
            print('Grabbing ticket info from headers...')
            rows = str(soup.select("h2", {"class": "subject"}))
            if(rows == '[]'):
                print(colored("No Headers", 'grey', 'on_red'))
            else:
                print(buffspace + '\n' + rows + '\n' + buffspace)
    else:
        print("Failed to read ticket.")
        print(grim, end='')
        time.sleep(.5)

# Run Program__________________________________________________________________
openPrgm()
inp = input('Enter the ticket number to pull...\n')
grabTicket(inp)