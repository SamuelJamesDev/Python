# -*- coding: utf-8 -*-
"""
Created on Mon Feb 14 14:26:03 2022

@author: SamuelJames
@How many tickets have I done/Have Open
"""

import requests 
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
import time
from colorama import init
from termcolor import colored
import argparse
import emoji

sun = emoji.emojize(':sunglasses:', use_aliases=True)
cry = emoji.emojize(':cry:', use_aliases=True)
fu = emoji.emojize(':fu:', use_aliases=True)
expr = emoji.emojize(':expressionless:', use_aliases=True)

# use Colorama to make Termcolor work on Windows too
init()

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    
def openPrgm():
    logo = '''
.     .#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#####(((((      
   ./%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%####(((#*   
 .((((####(#(#%####(####(((#(###(##(/(#(#(#%#(##((#((#((((((((((((((((((((//(%%.
%#(((((####(#%#(((##(##((##%&%###(////#((##%%(#(%%#(((###(((((((((##(((((((/###(
%#(((###(#(#&######%&#(##&&#/#(#(//////#((((%&#((##%&##(#%(((#(((((&#(((((((%%%(
%#(((#####%&%#(#(#&%####&(///(##////////#((#/(%&#((###&&##&%(((((((&#(#(####&&&#
%@@@@&&&&&&&%#(#%@%(##%#//(///#((&((((////#((#//(&%(((///%%&&##(((#&(%##&&&&&&&#
%@@@@&@@@&&&%##%@#//##(///(////#//#/////////(#///(((%&##(/(#&&%#(#&&&&%&&&&&&@&%
%@@@@@@@@@&@&##@%/###%%#####%%%####/////////#######%#####%###&&##&&&&&@&&&&&@@@%
#@@@@%%&&@@&%%#&%%%%%((((/(////(#%%##/////##%%#(////////((###&%&%//#@&&&&&@%&@@%
%*,,&&&&@@/##%%&%%%##((((((#(((((//#%#///#%%((((((((((((#(((/%#&&##((&&&&&&&@@@%
%.(&@#*,,,,*(((&%%%%%%%%%%%%%%###%%%%%%%%%%%%%%%%&&&&&&&&&&&&%####(/(&&&%(#&@@@%
%%%. ,.  .,**(/&%%&%##%%##%%%#%&&%&%%%%&%%%&%@&&&@&&&&&&&%%%%%@&&(/#&/#(((%&@@@%
%.   .*#*,,*,**//%%%&(((#&%&&%&%#%&&#(////%%%&#(##&&&&&&&#%%%(///#&&&&##%(&(%@@%
%/%%,,,.    .,**/(##%%&&%%%%%%%&&%((/////////(%&%%%%%%%%&&&##/(####%#(//((//%@@%
%            .,**(%(//((((((//(//////////////(/////((((((//%#######(///((//*#&&%
%.            ,,*/(%(////////////////////////////////////(%#######(////(/*/,#&%%
%.             *,*(#%#(/(///////////////////////////////#%#######//////(//,,#%%%
%.             ,***/##%%(//////////////////////////(//#%#######(//////((*,,,(%%%
%.              ,**/(#%##%%#(///////(#(#####(((////(#########(//////////,,, (%%%
%. . ..      ... ,**//(####%#%%(////////(//(///(#%#########(///////////,,,. (%%%
%..,  , .......,..,*,*//(#%####%#%%#(//////(%###########(/(/////////*//.., .(%&%
%. ,..,........,,.,, .,***/(##########%%###%#####%%##(((//(///////*,// ., ..(%&%
%..,,.,,........,,,,,... ..**,/(########%#####%##(///(((/(///////,,,* .,... #&%%
%..,*..,.. .  ..,,,**,,... ..  .***(#########(/(((/(///////////,,, *, ,,.  .(#%#
'''

    logo2 = '''
%,.,.*#%,...,(%%%%%,....(%%%%%%%%/......(%* ...(#,....(%*... ..../%#. ....*(%%%%
%,.. ,#%,   .(%%%%*      (%%%%.         (%*    /    ,#%%,        /%#         ./%
#*,.,       ,#%%(*       ,#%/    ,(%%%%%%#,       .(#%%(.   ...../%/    *(.   .(
%*    ,,.   ./*#%/   ,    *,(     ,//((/(*,        *,(%%,,   ..,,(,/    ,*     (
**    #%*   (%#     .((   /%%,        .(%*     (,   #%%,        /%%         .#%%
 */#%%%%####%###(#((#%%#((#%%%%#((#(((%%#(((#((#%#((###(((((#((#%%%%((##(#%%%#. 
'''
    print(colored(logo, 'white', 'on_blue'), end='')
    print(colored(logo2, 'white', 'on_grey'))
    time.sleep(1)


api_key = "26suLUhxIvs9IqPG0RFD"
password = "Welcome1"
buffspace = '''+++++++++++++++++++++++++++++++++++++++++++++++++'''

ticket_list = []

def getSearchInt():
    inp = input("Enter The # tickets to search through....\n")
    return int(inp)

def getHighestTicket():
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/tickets/", auth = (api_key, password), verify=False)
    print(colored("Retrieving highest ticket number, the response is given below\n", 'white', 'on_cyan') + str(colored(r.status_code, 'white', 'on_green')))
    #soup = BeautifulSoup(r.content, 'html.parser')
    data = r.json()
    #this method allows me to return only the ticket ID, which I can now set to the highest ticket number 
    print(colored("HIGHEST TICKET NUMBER: ", 'white', 'on_cyan'))
    print(data['tickets'][0]['id'])
    top_ticket = data['tickets'][0]['id']
    return top_ticket


def searchTickets(numSrch):
    num_tickets = 0
    i = getHighestTicket()
    y = 0
    while y < numSrch:
        r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/tickets/"
                         +str(i), auth = (api_key, password), verify=False)
        data = r.json()
        #print(data['ticket']['responder_id'])
        print('#', end='')
        if str(data['ticket']['responder_id']) == '15002306395':
            num_tickets = num_tickets+1
            ticket_list.append(str(i))
        i -= 1    
        y += 1
    per = (num_tickets / numSrch) * 100
    
    print("\nOut of the last #", numSrch, ' Tickets, I have done #', num_tickets, " Of them.")
    print(per, '% of tickets are mine')
    if per >= 60:
        print("TICKET GOD\n", sun, sun, sun, sun, sun)
    elif per < 60 and per > 40:
        print("LAZY IT GUY ACHIEVEMENT UNLOCKED\n", expr, expr, expr, expr, expr)
    elif per < 40 and per > 20:
        print("WHAT DO YOU EVEN DO ALL DAY?\n", fu, fu, fu, fu, fu)
    else:
        print("TRASH LEVEL IT GUY\n", cry, cry, cry, cry, cry)
    print("My Tickets:\n", ticket_list)

#Run Program
def doTheThing(srchNum):
    openPrgm()
    try:
        searchTickets(srchNum)
    except KeyboardInterrupt:
        print('Program Closed...')
        
parser = argparse.ArgumentParser(description='Count How Many Tickets I have')
parser.add_argument('-tn','--ticket_num', help='The # of tickets to check', required=True)

args = vars(parser.parse_args())
if int(args['ticket_num']) > 0:
    doTheThing(int(args['ticket_num']))
else:
    print("Please enter a valid number greater than zero")    
