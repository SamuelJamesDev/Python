# -*- coding: utf-8 -*-
"""
Created on Tue Apr 19 14:00:05 2022

@author: SamuelJames
this program can take a .data file and produce metrics given the file
"""

#!pip install wget
import numpy as np
import requests 
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
import time
import matplotlib.pyplot as plt
from colorama import init
from termcolor import colored
# use Colorama to make Termcolor work on Windows too
init()

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

api_key = "26suLUhxIvs9IqPG0RFD"
password = "Welcome1"

url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/lung-cancer/lung-cancer.data'

z = 0
av = 0
nls = 0
bar = ['▁', '▂', '▃', '▄', '▅', '▆', '▇', '█', '▇', '▆', '▅', '▄', '▃','▁']
barNum = 0

def whatTypeTicket(thing):
    global z, av, nls
    #do stuff
    if 'Zscaler' in thing or 'ZScaler' in thing:
        z = z+1
    elif 'nls' in thing or 'NLS' in thing:
        nls = nls+1
    elif 'Avaya' in thing or 'avaya' in thing:
        av = av+1

def getHighestTicket():
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/tickets/", auth = (api_key, password), verify=False)

    data = r.json()
    #this method allows me to return only the ticket ID, which I can now set to the highest ticket number 
    print("HIGHEST TICKET NUMBER: ")
    print(data['tickets'][0]['id'])
    top_ticket = data['tickets'][0]['id']
    return top_ticket

def searchTickets(numSrch):
    global barNum
    num_tickets = 0
    i = getHighestTicket()
    y = 0
    while y < numSrch:
        r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/tickets/"
                         +str(i), auth = (api_key, password), verify=False)
        data = r.json()
        print(colored(bar[barNum]*60, 'green', 'on_grey'), end = '\r')
        time.sleep(.5)
        
        if str(data['ticket']['responder_id']) == '15002306395':
            num_tickets = num_tickets+1
            whatTypeTicket(data['ticket']['subject'])
        i -= 1    
        y += 1
        barNum = barNum+1
        if barNum >= len(bar):
            barNum = 0
    print(colored('Count Complete...', 'green', 'on_grey'), end = '\r')

def doGraph():
    fig = plt.figure()
    ax = fig.add_axes([0,0,1,1])
    types = ['Avaya', 'ZSCALER', 'NLS']
    counts = [av, z, nls]
    ax.bar(types[0],counts[0], color = 'b', width = 0.25)
    ax.bar(types[1],counts[1], color = 'g', width = 0.25)
    ax.bar(types[1],counts[1], color = 'r', width = 0.25)
    ax.set_ylabel('Number of Tickets')
    ax.set_xlabel('Ticket Type')

    plt.show()

if __name__ == "__main__":
    inp = int(input('How many tickets to search?>> '))
    searchTickets(inp)
    doGraph()

#plt.bar(list(range())
#plt.show()
