# -*- coding: utf-8 -*-
'''
Author: Samuel James
Use: This program will scrape through listed users for licenses
Date: 2/3/2022
Name: Licensces.py
'''

import requests# pip install requests
import json # pip install JSON
from bs4 import BeautifulSoup # pip install bs4
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3 # pip install urllib3
import time # pip install time
from colorama import init # pip install colorama
from termcolor import colored # pip install termcolor
from collections import Counter # built in program
import pandas as pd # pip install pandas
import csv
# use Colorama to make Termcolor work on Windows too
init()

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

#___________________________________________________________Variables
#Program Logo
def openPrgm():
    logo = '''
GATHERING LICENSE INFO....
    '''
    print(colored(logo, 'cyan'))
    time.sleep(2)


api_key = "26suLUhxIvs9IqPG0RFD"
password = "Biggie556!"

apps = []
ins = []
users = []
ids = []

apps2 = []
ins2 = []
users2 = []
ids2 = []

names = [[]]
appnames = []
nums = []
#___________________________________________________________Functions

#retrieve users by name regardless of whether the user an agent or requester
def grabUser(req_id, num):
            #if no user ID exists return and continue iterating through tickets
            if(req_id is None):
                return
            #try grabbing from agents, except index error and search requesters
            try:
                r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/agents/"+
                                  str(req_id), auth = (api_key, password), verify=False)
                #parse to JSON
                data2 = r2.json()
                #grab name from JSON parsing
                name = (data2['agent']['first_name'] + ' ' + data2['agent']['last_name'])
                #add to our list of users
                names.append(name)
                
            except ValueError:
                #Not an agent
                r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/"+
                                  str(req_id), auth = (api_key, password), verify=False)
                #pull data2 and parse from JSON
                data2 = r2.json()
                try:
                    #parse name from JSON and add to our list of users
                    name = (data2['requester']['first_name'] + ' ' + 
                            data2['requester']['last_name'])
                    names.append(name)

                except TypeError:
                    name = (data2['requester']['first_name'])
                    names.append("No Name")

def grabLicenseUsers(id_in, num):
    rq = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/applications/" + str(id_in) + "/installations", auth = (api_key, password), verify=False)
    rdata = rq.json()
    try:
        for m in range(1, 200):
            grabUser(rdata['installations'][m]['user_id'], num)
            
    except IndexError:
        print("|", end="")
    
def intoLicense(ids):
    try:
        for l in range(len(ids)):
            print("|", end="")
            names.append(apps2[l])
            grabLicenseUsers(ids[l], l)
    except IndexError:
        print("All License Users have now been pulled")
        
#grab the subject of each ticket to append to the list of tickets to count
def grabLicenses(j):
    print("-", end="")
    #Run request for ticket URL
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/applications?per_page=50&page=" + j, auth = (api_key, password), verify=False)
    
    #If 200 <GOOD> response is received, parse into JSON data and grab ticket
    data = r.json()
    #print(data)
    for i in range(1, 50):
        apps.append(data['applications'][i]['name'])
        ins.append( data['applications'][i]['installation_count'])
        users.append(data['applications'][i]['user_count'])
        ids.append(data['applications'][i]['id'])


#simple pandas dataframe to turn appended values into a csv
def writeToCSV(apps, ins, users):
    df = pd.DataFrame({'License Name': apps, 
                       'Number of Installs': ins,
                       'Number of Users' : users})
    df.to_csv('License_Audit.csv', index= False)

def cleanLists(apps, ins, users):
    for k in range(len(apps)):
        if(users[k] > 0):# and ins[k] > 0):
            apps2.append(apps[k])
            ins2.append(ins[k])
            users2.append(users[k])
            ids2.append(ids[k])
            
def create_app_user_list(arr):
    df = pd.DataFrame({'Names': arr})
    df.to_csv('License_Users.csv', index= False)
#______________________________________________________________Run Program
openPrgm()
#try catch for Keyboard Exceptions for gracefully exiting
try:
    #for the range of licenses
    for j in range(1, 27):
        try:
            #grab each index of license
            grabLicenses(str(j))
        #except when we have hit the end of the index
        except IndexError:
            print("List Completely Iterated")
    
    #clean the list up
    cleanLists(apps, ins, users)
    #write info to csv
    #writeToCSV(apps2, ins2, users2)
    #try making a list of apps and users, but something is broken here
    intoLicense(ids)
    #print the usernames/app names
    for h in range(len(names)):
        print(names[h])
    
    #make a pretty csv of the users to licenses
    create_app_user_list(names)
        
except KeyboardInterrupt:
    print('Program Closed...')