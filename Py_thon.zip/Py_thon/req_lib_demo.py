# -*- coding: utf-8 -*-
"""
Created on Tue May  3 14:11:41 2022

@author: SamuelJames
"""

import FWRQ # the created library to test

#test1 = FWRQ.agentIds()
test2, names2 = FWRQ.reqIds()
#test3 = FWRQ.assetIds()

#print(test1)
for t in range(len(test2)):
    print(test2[t], names2[t])
#print(test3)

#print(FWRQ.specifyAgent(test1[0]))
print(FWRQ.specifyRequester(test2[0]))
#print(FWRQ.specifyAsset(test3[0]))