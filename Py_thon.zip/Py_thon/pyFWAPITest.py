# -*- coding: utf-8 -*-
"""
Created on Thu Apr 21 10:46:28 2022

@author: SamuelJames
"""

from freshservice.api import API, TicketAPI

key = "26suLUhxIvs9IqPG0RFD"
password = "Welcome1"

api = API(key, 'support.drivewayfinancecorp.com')
user_api = API(api)
asset_api = API(api)

user = user_api.search('SamuelJames@drivewayfinancecorp.com')
asset_list = asset_api.get_all()
assigned_hardware = []
for asset in asset_list:
    if asset.user_id == user.id:
        assigned_hardware.append(asset)
