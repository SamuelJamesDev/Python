# -*- coding: utf-8 -*-
"""
Created on Tue Apr 19 15:44:57 2022

@author: SamuelJames
"""

men = '''
0: EXIT
1: if loop
2: while loop
3: for loop
4: Variable
5: Function
6: print
7: show program so far
8: Clear current program
'''

iff = 'if '
whilee = 'while '
forr = 'for '
rng = ' in range '
var = ' = '
func = 'def '
prnt = 'print(\''


ifcount = 0
whilecount = 0
varcount = 0
fcount = 0
pcount = 0

program = []

def menu():
    print(men)
    inp = str(input('enter your choice:\n'))
    if inp == '0':
        exit()
    elif inp == '1':
        inif = str(input('if what?\n'))        
        program.append(iff + inif + ':\n\t')
        menu()
    elif inp == '2':
        inwhl = str(input('while what?\n'))        
        program.append(whilee + inwhl + ':\n\t')
        menu()
    elif inp == '3':
        infor = str(input('for what?\n'))   
        inrange = str(input('for what Range?\n'))   
        program.append(forr + infor + rng + inrange + ':\n\t')
        menu()
    elif inp == '4':
        nm = str(input('Var name?\n'))  
        amn = str(input('Var value (include quotes for strings)?\n'))  
        program.append(nm + var + amn)
        menu()
    elif inp == '5':
        fnm = str(input('Function name?\n'))  
        args = str(input('Arguments (enter nothing for no args)?\n'))  
        program.append(func + fnm + '(' + args + '):\n\t')
        menu()
    elif inp == '6':
        past = str(input('What should it print?\n'))
        program.append(prnt + past + '\')')
        menu()
    elif inp == '7':
        print('\n\n\n\n')
        for thing in program:
            print(thing)
        print('\n\n\n\n')
        menu()
    elif inp == '8':
        ans = input('Are you sure? [Y/N]')
        if ans == 'y' or ans == 'Y':
            program.clear()
            menu()
        else:
            menu()
    else:
        print('invalid entry, try again...\n')
        menu()
        
if __name__ == '__main__':
    try:
        menu()
    except KeyboardInterrupt:
        print('\t\t\t Goodbye...')