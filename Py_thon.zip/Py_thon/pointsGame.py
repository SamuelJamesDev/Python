# -*- coding: utf-8 -*-
#!/usr/bin/env python
"""
Created on Fri Feb 25 12:28:39 2022

@author: SamuelJames
"""

import requests 
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3
from termcolor import colored
import matplotlib.pyplot as plt
import numpy as np

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Variables____________________________________________________________________
#API key works, password does not matter
api_key = "26suLUhxIvs9IqPG0RFD"
password = "Biggie556!" 
#this can be any made up password, it doesn't actually check

judge_me = []
score = []
fin = []

def getHighestTicket():
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/tickets/", auth = (api_key, password), verify=False)
    print(colored("Retrieving highest ticket number, the response is given below\n", 'white', 'on_cyan') + str(colored(r.status_code, 'white', 'on_green')))
    #soup = BeautifulSoup(r.content, 'html.parser')
    data = r.json()
    #this method allows me to return only the ticket ID, which I can now set to the highest ticket number 
    print(colored("HIGHEST TICKET NUMBER: ", 'white', 'on_cyan'))
    print(data['tickets'][0]['id'])
    top_ticket = data['tickets'][0]['id']
    return top_ticket

def grabPoint():
    r = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/agents", auth = (api_key, password), verify=False)
    if r.status_code == 200:
        print(colored("Request processed successfully, the response is given below\n", 'white', 'on_green') + str(colored(r, 'white', 'on_cyan')))

        data = r.json()
        print(data)
        try:
            for i in range(13):
                judge_me.append(data['agents'][i]['first_name'])
                score.append(data['agents'][i]['scoreboard_points'])
        except IndexError:
            print('End of agents')
    else:
        print(">:(")

def JUDGMENT(lt):
    sorted_list = sorted(zip(judge_me, score))
    sorted_list1 = [element for _, element in sorted_list]
    #print(sorted_list1)
    
    #for l in range(len(sorted_list)):
    #    print(sorted_list[l])
    
    return sorted_list
            
def graph(y):
    plt.xlabel("X-axis")
    plt.ylabel("Y-axis")
    plt.title("A test graph")
    for x in range(len(score)):
        if score[x] != None and score[x] > 0:
            print(score[x])
            plt.plot(int(score[x]), y, label = judge_me[x])
    plt.legend()
    plt.show()
    
grabPoint()
check = JUDGMENT(judge_me)
for elm in check:
    print(elm)
high_t = getHighestTicket()
graph(high_t)
            