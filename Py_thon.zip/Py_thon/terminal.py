# -*- coding: utf-8 -*-
"""
Created on Mon Mar 28 14:24:29 2022

@author: SamuelJames
"""
from tkinter import *
import subprocess
from datetime import date
from ttkthemes import ThemedStyle

PASSWORD = ''
#retrieve the password
def getpwd():
    global PASSWORD
    root = Tk()
    pwdbox = Entry(root, show = '*')

    def onpwdentry(evt):
        global PASSWORD 
        PASSWORD = pwdbox.get()
        root.destroy()
    def onokclick():     
        global PASSWORD
        PASSWORD = pwdbox.get()
        root.destroy()

    Label(root, text = 'Password').pack(side = 'top')

    pwdbox.pack(side = 'top')
    pwdbox.bind('<Return>', onpwdentry)
    Button(root, command=onokclick, text = 'OK').pack(side = 'top')

    root.mainloop()
    return PASSWORD

#check the password
def checkpwd(check):
    file = open("password.txt", "r")
    if str(check) == str(file.read()):
        print('ENTRY GRANTED ;)')
        return True
    else:
        print("GET OUT OF MY TERMINAL YAH F00KIN SCRUB")
        return False
    
#the fake background terminal
def run(event):
    command = cmd.get('1.0', 'end').split('\n')[-2]
    
    if str(command) == 'date':
        cmd.insert('end', f'\n' + str(date.today()))
    elif str(command) == 'clear':
        delete()
    else:
        cmd.insert('end', f'\n{subprocess.getoutput(command)}')
    #subprocess.Popen(command)

def esc(event):
    exit()
    
def delete():
   cmd.delete("1.0","end")
   
def open_pages(event):
   mycmd = 'Startup.bat'
   subprocess.Popen(mycmd, cwd=r"C:\Users\SamuelJames\OneDrive - Lithia Motors, Inc\Desktop")
   
try:
    check = getpwd()
    cont = checkpwd(check)
    if cont:
        root = Tk()
        root.title("R34P3R Terminal")
        root.configure(bg="white")
        
        cmd = Text(root)
        cmd.pack()
    
        cmd.bind('<Return>', run)
        cmd.bind('<Escape>', esc)
        cmd.bind('<F1>', open_pages)

        root.mainloop()
    else:
        exit()
    
except KeyboardInterrupt:
    print('goodbye')