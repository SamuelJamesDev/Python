# -*- coding: utf-8 -*-
"""
Created on Wed Feb 16 11:59:55 2022

@author: SamuelJames
"""

import serial as ser
import serial.tools.list_ports as prtlst


def printPorts():
    myports = [tuple(p) for p in list(ser.tools.list_ports.comports())]
    for pt in myports:
        print(pt)
    print(ser.tools.list_ports.comports())
    
printPorts()