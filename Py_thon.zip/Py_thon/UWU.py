# -*- coding: utf-8 -*-
"""
Created on Tue Mar  8 15:03:11 2022

@author: SamuelJames
@Make shit into an UWU sentence
"""

change = input('Enter your sentence:\n')

l = list(change)
print(l)
for x in range(len(l)):
    if l[x] == 'r':
        l[x] = 'W'
    elif l[x] == 'u':
        l[x] == 'UWU'
print(''.join(l))
