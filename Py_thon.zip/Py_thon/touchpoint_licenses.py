# -*- coding: utf-8 -*-
"""
Created on Wed Mar  9 15:53:30 2022

@author: SamuelJames
For testing various API calls
"""

import requests# pip install requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning# also urllib3
import urllib3 # pip install urllib3
import pandas as pd # pip install pandas
import time # standard package
import os # standard package
# Import date class from datetime module
from datetime import date

#Removes erronious warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

#_____________________________________________________________________Overview
# Step 1: Pull all managed licenses
# Step 2: Iterate through each user under application -> Users 
# Step 3: Compile all applications and users into one CSV File

# Note, run program with Python -u to prevent buffering of stdout output
# if you would like to see the total runtime while the program runs

#____________________________________________________________________Variables

api_key = "26suLUhxIvs9IqPG0RFD"
password = "Password"
start_time = time.time()

#2d list to contain license name and users under that license.
names = []

#____________________________________________________________________Functions

#retrieve users by name regardless of whether the user an agent or requester
def grabUser(req_id):
            #if no user ID exists return and continue iterating through tickets
            if(req_id is None):
                return
            #try grabbing from agents, except index error and search requesters
            try:
                r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/agents/"+
                                  str(req_id), auth = (api_key, password), verify=False)
                #parse to JSON
                data2 = r2.json()
                #grab name from JSON parsing
                name = (data2['agent']['first_name'] + ' ' + data2['agent']['last_name'])
                #add to our list of users
                if name not in names:
                        names.append(name)
            except ValueError:
                #Not an agent
                r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/"+
                                  str(req_id), auth = (api_key, password), verify=False)
                #pull data2 and parse from JSON
                data2 = r2.json()
                try:
                    #parse name from JSON and add to our list of users
                    name = (data2['requester']['first_name'] + ' ' + 
                            data2['requester']['last_name'])
                    if name not in names:
                        names.append(name)
                #Not an Agent and has only one name i.e. looker or noreply
                except TypeError:
                    #parse only 1st name from JSON and add to our list of users
                    name = (data2['requester']['first_name'])
                    if name not in names:
                        names.append(name)

def grabLicenseUsers():
    for i in range(1, 15):
        try:
            #use ID to pull users from license "Users" page
            rq = requests.get('https://drivewayfinancecorp.freshservice.com/api/v2/applications?filter=value:managed', auth = (api_key, password), verify=False)
            rdata = rq.json()
            #print(rq.headers['X-Ratelimit-Remaining'])
            #for m in range(1, 100):
            #    print(rdata['application_users'][m]['id'])
            print(rdata)
                #grabUser(rdata['application_users'][m]['user_id'])
        except IndexError:
            print('End of Users page: ', i)
            
def grabLicenseUsers_Installs():
    names.append('Touchpoint')
    for j in range(1, 3):
        try:
            rdata = []
            rq = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/applications/15011922405/installations", auth = (api_key, password), verify=False)
            rdata=(rq.json())
            #print(rdata)
            
            for thing in rdata['installations']:
                if thing['user_id'] is not None:
                    print(thing['user_id'])
            
            #test = [entry['user_id'] for entry in rdata['installations'] if entry['user_id'] != None]
            #for ids in test:
            #    grabUser(ids)
            #for m in range(1, 100):
            #    grabUser(rdata['installations'][m]['user_id'])

        except IndexError:
            print('End of Users page: ', j)
            
def create_app_user_list(arr):
    today = date.today()
    filePath = 'LicensesT' + '_' + (str(today)) + '.csv'
        
    df = pd.DataFrame([x for x in arr if x != None]).transpose()
    #create transposed dataframe to make sure each license is a column not a row.
    #df2 = df.transpose()
    
    #drop first row 
    #df = df.iloc[: , 1:]
    #df2.reset_index(drop = True)
    #Make the csv, remove numbered header
    df.to_csv(filePath, index=False, mode='a')

def run_in_full():
    try:
       # names.append('Touchpoint')        
        #$grabLicenseUsers()
        grabLicenseUsers_Installs()
        print(names)
        #make a csv of the users to licenses
        #create_app_user_list(names)
    
        #runtime to reduce runtime before finishing program
        print("\n--- %.2f minute runtime---" % ((time.time() - start_time) / 60))
    #if we hit a connection error, recursively attempt to re-try the function
    except requests.exceptions.RequestException as e:
        print('\nEncountered Connection Error: ', e)
        print('\nforcing re-run...') 
        run_in_full()

#__________________________________________________________________Run Program

#try catch for Keyboard Exceptions for gracefully exiting
try:
    run_in_full()
    
#Also cover connections exceptions for graceful restarts
except KeyboardInterrupt:
    print('\nProgram Force Closed...')