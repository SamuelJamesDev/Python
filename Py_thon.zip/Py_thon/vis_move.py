# -*- coding: utf-8 -*-
"""
Created on Tue May  3 16:16:31 2022

@author: SamuelJames
"""

array = list('''
0 - - - -
- - - - -
- - - - - 
''')

print(''.join(str(x) for x in array))

array[0] = '-'
array[1] = ' 0'
array[5] = ''

print(''.join(str(x) for x in array))