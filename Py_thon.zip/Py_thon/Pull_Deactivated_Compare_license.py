# -*- coding: utf-8 -*-
"""
Created on Tue Feb  8 10:37:12 2022

@author: SamuelJames
"""

import requests# pip install requests
import json # pip install JSON
from bs4 import BeautifulSoup # pip install bs4
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib3 # pip install urllib3
import time # pip install time
from colorama import init # pip install colorama
from termcolor import colored # pip install termcolor
from collections import Counter # built in program
import pandas as pd # pip install pandas
import csv
# use Colorama to make Termcolor work on Windows too
init()

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

#___________________________________________________________Variables
#Program Logo
def openPrgm():
    logo = '''
VACANT LOGO
    '''
    print(colored(logo, 'cyan'))
    time.sleep(2)


api_key = "26suLUhxIvs9IqPG0RFD"
password = "Biggie556!"

deactivated = []
deacc = []
#___________________________________________________________Functions

#remove duplicate names
def duplicate_removal(the_list):
    res = []
    for i in the_list:
        if i not in res:
            res.append(i)
    return res
            
#retrieve users by name regardless of whether the user an agent or requester
def grabUser(req_id):
            #if no user ID exists return and continue iterating through tickets
            if(req_id is None):
                return

            #Not an agent
            r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters/"+
                              str(req_id), auth = (api_key, password), verify=False)
            #pull data2 and parse from JSON
            data2 = r2.json()
            #print(data2)
            try:
                isActive = (data2['requester']['active'])
                if(str(isActive) == 'False'):
                    #print("Deactivated")
                    #parse name from JSON and add to our list of users
                    name = (str(data2['requester']['first_name']) + ' ' + str(data2['requester']['last_name']))
                    
                    deactivated.append(name)

            except TypeError:
                if(str(isActive) == 'False'):
                    name = (str(data2['requester']['first_name']))
                    deactivated.append(name)

def grab_IDs(page):
    r2 = requests.get("https://drivewayfinancecorp.freshservice.com/api/v2/requesters?per_page=100&page=" + str(page), auth = (api_key, password), verify=False)
    #pull data2 and parse from JSON
    data = r2.json()
    #print(data)
    print('\nLoading Deactivated Users for page ' + str(page) + ':', end='')
    for i in range(100):
        print('#',end='')
        #print(data['requesters'][i]['id'])
        req_id = data['requesters'][i]['id']
        grabUser(req_id)

def writeToCSV(deacc):
    df = pd.DataFrame({'Deactivated Users': deacc})
    df.to_csv('Deactivated_Users.csv', index= False)

def pullAndCompCSV(arr):
    Output = []
    final = []
    with open('test.csv', 'r') as file:
        for line in file:
            Output.append(line.strip())
    #print(Output)
    final = set(arr).intersection(Output)
    final = sorted(final, key=str.upper)
    for nm in final:
        print(nm)

try:
    try:
        for h in range(1, 6):
            grab_IDs(h)
    except IndexError:
        print("Hit the end...")
    deacc = duplicate_removal(deactivated)
    #print(deacc)
    writeToCSV(deacc)
    pullAndCompCSV(deacc)
    
except KeyboardInterrupt:
    print('Program Closed...')